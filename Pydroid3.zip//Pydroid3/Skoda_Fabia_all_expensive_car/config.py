import sqlite3
import traceback
import sys
import time
from datetime import datetime
import math
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

date = time.strftime("%Y-%m-%d %H:%M")
today = date
date_object_now = datetime.now()

class Car:
	def record_maintenance():
			category = "Mantenance_"
			name = input("name of mantenance, exsemple 0 or 1 or 2: ")
			name = category + name
			comment = input("enter action: ")
			deals = input("enter parametres")
			with sqlite3.connect('cars_app.db') as con:
				cursor = con.cursor()
				sqlite_insert_query = """INSERT INTO total_data_02(date, name_of_expencies, comment, category, deals)  VALUES  (?, ?, ?, ?, ?)"""
				count = cursor.execute(sqlite_insert_query, (date, name, comment, category, deals))
				con.commit()
	
	def data_to_email():
		try:
			mail_content = '''backup of cars app ''' + date
			sender_address = "anatole.yakovlev@gmail.com"
			sender_pass = "tbunoakrikzyszdv"
			receiver_address = "antiohy@mail.ru"
			message = MIMEMultipart()
			message['From'] = sender_address
			message['To'] = receiver_address
			message['Subject'] = 'A backup mail sent by cars apl. It has an attachment. ' + date
			message.attach(MIMEText(mail_content, 'plain'))
			attach_file_name = 'cars_app.db'
			attach_file = open(attach_file_name, 'rb')
			payload = MIMEBase('application', 'octate-stream')
			payload.set_payload((attach_file).read())
			encoders.encode_base64(payload)
			payload.add_header('Content-Decomposition', 'attachment', filename=attach_file_name)
			message.attach(payload)
			session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
			session.starttls() #enable security
			session.login(sender_address, sender_pass) #login with mail_id and password
			text = message.as_string()
			session.sendmail(sender_address, receiver_address, text)
			session.quit()
		except:
			print(f"{'check internet connection'}")
		
	def notice():
		with sqlite3.connect('cars_app.db') as con:
			cursor = con.cursor()
			result = """SELECT name_of_expencies, comment, finish_time from total_data_02 WHERE category is 'deals' GROUP BY DATE"""
			data = cursor.execute(result)
			for i in data:
				print(i[0], i[1], i[2])
				date_string = i[2]
				date_object = datetime.strptime(date_string, "%Y-%m-%d")
				date_object = date_object - date_object
			#	print("bingo", date_object)
		
		
	def record_deal():
		category = "deals"
		name = input("enter name: ")
		comment = input("enter all operations  : ")
		duration = int(input("duration:"))
		finish = input("enter the finish: ")
		with sqlite3.connect('cars_app.db') as con:
			cursor = con.cursor()
			sqlite_insert_query = """INSERT INTO total_data_02(date, name_of_expencies, duration, finish_time, comment, category)  VALUES  (?, ?, ?, ?, ?, ?)"""
			count = cursor.execute(sqlite_insert_query, (date, name, duration, finish, comment, category))
			
			con.commit()
	
	def showing_deals():
		with sqlite3.connect('cars_app.db') as con:
			cursor = con.cursor()
			result = """SELECT name_of_expencies, comment from total_data_02 WHERE category is 'deals' """
			data = cursor.execute(result)
			for i in data:
				print(i[0], i[1])
				
	def expenditure():
				name_of_expencies = input("name_of_expencies: ")
				money = float(input("sum: "))
				distance = float(input("km: "))
				time = int(input("time: "))
				category = "expenditure"
				date = today
				comment = input("inter comment or press 'inter': ")
				with sqlite3.connect('cars_app.db') as con:
				                    	sqlite_insert_query = """INSERT INTO total_data_02(date, money,  name_of_expencies, distance, category, duration, comment)  VALUES  (?, ?, ?, ?, ?, ?, ?)"""
				                    	count = con.execute(sqlite_insert_query, (date, money, name_of_expencies, distance, category,  time, comment))
				                    	con.commit()
	
	def filling():
			money = float(input("sum: "))
			litres = float(input("litres: "))
			time = int(input("time: "))
			distance = float(input("km: "))
			name_of_expencies = "petrol_92_atum"
			category = "filling"
			date = today
			comment = input("inter comment or press 'inter': ")
			with sqlite3.connect('cars_app.db') as con:
			                     	cursor = con.cursor()
			                     	sqlite_insert_query = """INSERT INTO total_data_02(date, money,  name_of_expencies, distance, category, duration, comment, litres)  VALUES  (?, ?, ?, ?, ?, ?, ?, ?)"""			                     	
			                     	count = con.execute(sqlite_insert_query, (date, money, name_of_expencies, distance, category,  time, comment, litres))
			                     	con.commit()
			                     	
	def data_of_car():
			 total_sum = litrkm = litrage = all_litres = 0
			 with sqlite3.connect('cars_app.db') as con:
			 	cursor = con.cursor()
			 	total_request = """SELECT sum(money), min(distance), max(distance), sum(litres), max(litres) from total_data_02"""
			 	total_data = cursor.execute(total_request)
			 	cursor = con.cursor()
			 	filling_result = """ SELECT sum(money), max(rowid), litres from total_data_02 WHERE category is 'filling' """			 	
			 	filling_data = cursor.execute(filling_result)
			 	for i in total_data:
			 			max_killometrage = i[2]
			 			total_sum = math.ceil(i[0])
			 			my_killometrage = i[2]- i[1]
			 			all_litres = i[3]
			 	total_price_of_km = math.ceil(total_sum / my_killometrage)		
			 	for i in filling_data:
			 		all_money_filling = i[0]
			 		last_filling = i[2]
			 	price_of_km = math.ceil(all_money_filling/my_killometrage)
			 	litrkm = math.ceil((all_litres /my_killometrage) * 1000)
			 	litrage = (math.ceil((all_litres / my_killometrage) * 1000)) / 10
			 	rated_distance = (math.ceil(1000 / litrkm) * 17)
			 	print(f'{"max_distance:":>23}{max_killometrage:5}{"km.":>4}')
			 	print(f"{'total sum:':>23}{total_sum}{'rubles.':>8}")
			 	print(f'{"my_killometrage:":>23} {my_killometrage:>5} {"km"}')
			 	print(f'{"all_petrol:":>23}{all_litres:6}{"litres.":>8}')
			 	print(f'{"rated_distance:":>23}{rated_distance:6}{"km.":>4}')
			 	print(f'{"total_price_of_km:":>23} {total_price_of_km:5}{"rubles.":>8}')			 	
			 	print(f'{"litrkm:":>23}{litrkm:>6}{"gramm.":>7}')
			 	print(f'{"litrage: ":>24}{litrage:>7}{"litr/km":>8}')			 	
			 	print(f'{"price_of_km:":>23}{price_of_km:>6} {"rubles"}')			 	
			 	con.commit()
			

class Backup_of_code:
	
	def data_to_email():
		mail_content = '''backup of cars app ''' + date
		sender_address = "anatole.yakovlev@gmail.com"
		sender_pass = "tbunoakrikzyszdv"
		receiver_address = "antiohy@mail.ru"
		message = MIMEMultipart()
		message['From'] = sender_address
		message['To'] = receiver_address
		message['Subject'] = 'backup of code of cars apl.' + date
		message.attach(MIMEText(mail_content, 'plain'))
		attach_file_name = 'cars_app.db'
		attach_file = open(attach_file_name, 'rb')
		payload = MIMEBase('application', 'octate-stream')
		payload.set_payload((attach_file).read())
		encoders.encode_base64(payload)
		payload.add_header('Content-Decomposition', 'attachment', filename=attach_file_name)
		message.attach(payload)
		session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
		session.starttls() #enable security
		session.login(sender_address, sender_pass) #login with mail_id and password
		text = message.as_string()
		session.sendmail(sender_address, receiver_address, text)
		session.quit()

codies_backup = Backup_of_code

#codies_backup.data_to_email()

car = Car

#car.record_mantenance()