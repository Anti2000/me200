
#fabia car
import time
from datetime import datetime
from config import car

today = time.strftime("%Y-%m-%d %H:%M")

start_time = time.time()

def main():
	car.data_of_car()

	while True:
		car.showing_deals()
		try:
			command =input("Choose category: filling petrol - 0, repair - 1, enter deal - 2, maintenance - 3, break - @: ")
			if command == "0":
				car.filling()
			elif command == "1":
				car.expenditure()
			elif command == "2":
				car.record_deal()
			elif command == "3":
				car.record_maintenance()
			elif command == "@":
				break
		except command as error:
			print(command)

if __name__ == "__main__":
    main()
  #  car.data_to_email()
    print('finish_time:', time.time() - start_time)