import sqlite3
import traceback
import sys
import time
from datetime import datetime, timedelta

today = time.strftime("%Y-%m-%d")

#dn = time.strftime("%A")
#hour = time.strftime("%H")

print(today)

def print_time_count(total_time_count, overtime_count):
	for i in overtime_count:
		print("bingo3:", i)
	print(f'{"monthy total time: "}{ total_time_count}{"monthly add time: "}{overtime_count}')

def define_overtime(shift, income, outcome):
	if shift == 1:
		the_shift_end = today + " " + "16" + ":" + "00"
		the_shift_end = confert_in_timedelta(the_shift_end)
		overtime = outcome - the_shift_end
		dinner = today + " " + "12" + ":" + "00"
		dinner = confert_in_timedelta(dinner)
		first_time = dinner - income
		evening = today + " " + "16" + ":" + "00"
		evening = confert_in_timedelta(evening)
		dinner = today + " " + "13" + ":" + "00"
		dinner = confert_in_timedelta(dinner)
		second_time = evening - dinner
		total_time = first_time + second_time
	if shift == 3:
		the_shift_end = today + " " + "06" + ":" + "00"
		the_shift_end = confert_in_timedelta(the_shift_end)
		overtime = outcome - the_shift_end
		print("bingo:", overtime)
		overtime = 4
		input()
#	print(f"{'overtime}{overtime}")
	
	return overtime


def take_dbs_over_time():
	   	try:
	   		sqlite_connection = sqlite3.connect('sqlite_time-book.db')
	   		cursor = sqlite_connection.cursor()
	   		overtime_count = cursor.execute(f'SELECT STRFTIME("%m-%Y", outcome) AS production_month, SUM(add_time) AS count FROM time_book_03 GROUP BY STRFTIME("%m-%Y", outcome)')
	   		overtime_count = list(overtime_count)
	   		sqlite_connection.commit()
	   	except sqlite3.Error as error:
	   		print("Ошибка при подключении к sqlite", error)
	   	finally:
	   	   		if (sqlite_connection):
	   	   			sqlite_connection.close()
	   	   			print("Соединение с SQLite закрыто")
	   	
	   	return overtime_count


def take_dbs_time_data():
	   	try:
	   		sqlite_connection = sqlite3.connect('sqlite_time-book.db')
	   		cursor = sqlite_connection.cursor()
	   		var = "2023-01-24 08:10:00"
	   		data = cursor.execute(f'SELECT STRFTIME("%m-%Y", outcome) AS production_month, SUM(total_time) AS count FROM time_book_03 GROUP BY STRFTIME("%m-%Y", outcome)')
	   		total_time = list(data)
	   		for i in data:
	   			print(i)
	   			sqlite_connection.commit()
	   	except sqlite3.Error as error:
	   		print("Ошибка при подключении к sqlite", error)
	   	finally:
	   	   		if (sqlite_connection):
	   	   			sqlite_connection.close()
	   	   			print("Соединение с SQLite закрыто")
	   	return total_time


def confert_in_timedelta(time):
	deltatime = datetime.strptime(time, "%Y-%m-%d %H:%M")
	return deltatime


def define_total_time(shift, income, outcome):
#	total_time = 7
	today = datetime.strftime(datetime.today(), "%Y-%m-%d")
	if shift == 1:
		dinner = today + " " + "12" + ":" + "00"
		dinner = confert_in_timedelta(dinner)
		first_time = dinner - income
		evening = today + " " + "16" + ":" + "00"
		evening = confert_in_timedelta(evening)
		dinner = today + " " + "13" + ":" + "00"
		dinner = confert_in_timedelta(dinner)
		second_time = evening - dinner
		total_time = first_time + second_time
	if shift == 3:
		shift_start_day =  datetime.today()- timedelta(days=1)
		shift_start_day = datetime.strftime(shift_start_day, "%Y-%m-%d")
		#shift_start = str(datetime.today() - timedelta(days=1))
		shift_start = shift_start_day + " " + "22" + ":" + "30"
		print("qwe", shift_start)
		dinner = today + " " + "02" + ":" + "00"
		dinner = confert_in_timedelta(dinner)
		shift_start = confert_in_timedelta(shift_start)
		#shifts_start = ""
		print(type(shift_start))
		first_time = dinner - shift_start
		print("first time: ", first_time)
		print(dinner, income)
		##
		evening = today + " " + "06" + ":" + "00"
		evening = confert_in_timedelta(evening)
		dinner = today + " " + "02" + ":" + "30"
		dinner = confert_in_timedelta(dinner)
		second_time = evening - dinner
		total_time = first_time + second_time
	total_time = str(total_time)
	return total_time


def define_dn(income):
	dn = datetime.strftime(income, "%A")
	return dn
	

def define_income(outcome, shift):
	
	if shift == 3:
		outcome = datetime.today() - timedelta(days=1)
		outcome = datetime.strftime(outcome, "%Y-%m-%d")
		outcome = outcome + " " + "20" + ":" + "00"
		income = datetime.strptime(outcome, "%Y-%m-%d %H:%M")
		
	elif shift == 1:
		income = datetime.strftime(datetime.today(), "%Y-%m-%d")
		income = income + " " + "08:00"
		income = datetime.strptime(income, "%Y-%m-%d %H:%M")
	return income


def job_mode(outcome, shift = 1):
	outcome = str(outcome)
	hour = int(outcome[10:13])
	if 21> hour > 16:
		shift = 1
	elif 12 > hour > 6:
		shift = 3
	
	return shift


def enter_time_back_income():
	intime =  input(f'{"ENTER TIME outcome: "}')
	hour = intime[:2]
	minutes = intime[2:4]
	outcome = today + " " + hour + ":" + minutes
	outcome = datetime.strptime(outcome, "%Y-%m-%d %H:%M")
	return outcome


def writing_db(income, outcome, dn, shift, total_time, add_time):
	                       	try:
	                       		sqlite_connection = sqlite3.connect('sqlite_time-book.db')
	                       		cursor = sqlite_connection.cursor()
	                       		print("База данных подключена к SQLite")
	                       		sqlite_insert_query = """INSERT INTO time_book_03(income, outcome, weekday, shift, total_time, add_time) VALUES (?, ?, ?, ?, ?, ?)"""
	                       		count = cursor.execute(sqlite_insert_query, (income, outcome, dn, shift, total_time, add_time))
	                       		sqlite_connection.commit()
	                       		
	                       		print("Запись успешно вставлена ​​в таблицу sqlitedb_objects", cursor.rowcount)
	                       		cursor.close()
	                       	
	                       	except sqlite3.Error as error:
	                       		print("Не удалось вставить данные в таблицу sqlite")
	                       		print("Класс исключения: ", error.__class__)
	                       		print("Исключение", error.args)
	                       		print("Печать подробноcтей исключения SQLite: ")
	                       		exc_type, exc_value, exc_tb = sys.exc_info()
	                       		print(traceback.format_exception(exc_type, exc_value, exc_tb))
	                       	
	                       	finally:
	                       	   		if (sqlite_connection):
	                       	   			sqlite_connection.close()
	                       	   			print("Соединение с SQLite закрыто")


def main():
	       over_time = take_dbs_over_time()
	       total_time_count = take_dbs_time_data()
	       print_time_count(total_time_count, over_time)
	       # 12 hours,  1 swift
	       outcome = enter_time_back_income()
	       shift = job_mode(outcome)
	       income = define_income(outcome, shift)
	       dn = define_dn(income)
	       print(shift, dn, income)
	       total_time = define_total_time(shift, income, outcome)
	       overtime = define_overtime(shift, income, outcome)
	       writing_db(income, outcome, dn, shift, total_time, overtime)
	       
	       	
if __name__ == "__main__":
    main()