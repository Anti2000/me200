import sqlite3
import traceback
import sys
from datetime import datetime

now = datetime.now()
print(now)


 #   sqlite_connection = sqlite3.connect('sqlite_time-book1.db')
#                                income datetime,
         #                       outcome datetime,
                         #       weekday TEXT,
           #                     shift TEXT,
                     #           total_time INTEGER,
                       #         add_time INTEGER,
           #                     comment TEXT);'''



def tranfering_data_btw_tables():
    #conn = sqlite3.connect("sqlite_attemp_05.db")
    #cursor = conn.execute("SELECT * FROM sqlitedb_objects", )
    try:
            sqlite_connection = sqlite3.connect('sqlite_time-book.db')
            cursor = sqlite_connection.cursor()
            print("База данных подключена к SQLite")
            sqlite_insert_query = """INSERT INTO time_book_03(income, outcome, weekday, shift, total_time, add_time, comment)
SELECT income, outcome, weekday, shift, total_time, add_time, comment FROM time_book_02"""
            #date_sql = (id, model, direction, creaties_date, date_of_arrival, date_of_sale, retail_price, prime_cost, delivery_in_town, vine_line, comment)
            count = cursor.execute(sqlite_insert_query)
            sqlite_connection.commit()
            print("Запись успешно вставлена ​​в таблицу sqlitedb_objects", cursor.rowcount)
            cursor.close()
    except sqlite3.Error as error:
            print("Не удалось вставить данные в таблицу sqlite")
            print("Класс исключения: ", error.__class__)
            print("Исключение", error.args)
            print("Печать подробноcтей исключения SQLite: ")
            exc_type, exc_value, exc_tb = sys.exc_info()
            print(traceback.format_exception(exc_type, exc_value, exc_tb))
    finally:
            if (sqlite_connection):
                sqlite_connection.close()
                print("Соединение с SQLite закрыто")



tranfering_data_btw_tables()


print(now)
