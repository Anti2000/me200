import sqlite3
import traceback
import sys
import time
from datetime import datetime, timedelta

today = time.strftime("%Y-%m-%d")


#
def define_income(outcome):
	outcome = datetime.today() - timedelta(days=1)
	outcome = datetime.strftime(outcome, "%Y-%m-%d")
	outcome = outcome + " " + "20" + ":" + "00"
	outcome = datetime.strptime(outcome, "%Y-%m-%d %H:%M")
	return outcome

def job_mode():
	pass

def enter_time_back_income():
	intime =  input(f'{"ENTER TIME income: "}')
	hour = intime[:2]
	minutes = intime[2:4]
	income = today + " " + hour + ":" + minutes
	income = datetime.strptime(income, "%Y-%m-%d %H:%M")
	
	#intime =  input(f'{"ENTER TIME outcome: "}')
#	hour = intime[:2]
#	minutes = intime[2:4]
#	outcome = today + " " + hour + ":" + minutes
#	outcome = datetime.strptime(outcome, "%Y-%m-%d %H:%M")
	#time = (income, outcome)
	return income

def writing_db(income, outcome):
#	income = time[0]
#	outcome = time[1]
	print(income)
	print(outcome)
	try:
	                       	sqlite_connection = sqlite3.connect('sqlite_time-book.db')
	                       	cursor = sqlite_connection.cursor()
	                       	print("База данных подключена к SQLite")
	                       #	sqlite_insert_query = """INSERT INTO time_book(outcome) VALUES (?)"""
	                       #	date_sql = (outcome)
	                       	sqlite_insert_query = """INSERT INTO time_book(income, outcome) VALUES (?, ?)"""
	                       	#date_sql = ([outcome], [income])
	                       	count = cursor.execute(sqlite_insert_query, (income, outcome))
	                       #	count = cursor.execute(sqlite_insert_query, [date_sql])
	                       	sqlite_connection.commit()
	                       	
	                       	print("Запись успешно вставлена ​​в таблицу sqlitedb_objects", cursor.rowcount)
	                       	cursor.close()
	                       	
	except sqlite3.Error as error:
	                       	print("Не удалось вставить данные в таблицу sqlite")
	                       	print("Класс исключения: ", error.__class__)
	                       	print("Исключение", error.args)
	                       	print("Печать подробноcтей исключения SQLite: ")
	                       	exc_type, exc_value, exc_tb = sys.exc_info()
	                       	print(traceback.format_exception(exc_type, exc_value, exc_tb))
	                       	
	finally:
	                           	if (sqlite_connection):
	                           		sqlite_connection.close()
	                           		print("Соединение с SQLite закрыто")


def main():
	       # 12 hours,  1 swift
	       outcome = enter_time_back_income()
	       income = define_income(outcome)
	       writing_db(income, outcome)
	       
	       	
if __name__ == "__main__":
    main()