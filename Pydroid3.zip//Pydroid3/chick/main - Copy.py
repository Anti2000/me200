import time
from datetime import datetime
from config_x import aviability
from config_x import buying
from config_x import sellings

# add player
#today = str(datetime.now())
#today = time.strftime("%Y-%m-%d-%M-%s")
# pdb
# timeit

start_time = time.time()

def main():
	while True:
		try:
			command =input("enter command: 0 - aviability - buying - 1, sellings - 2, break - X: ")
			if command == "0":
				aviability()
			elif command == "1":
				buying()
			elif command == "2":
				sellings()
			elif command == "X":
				break
		except ex as error:
			print("incorrect command, try again")

if __name__ == "__main__":
    main()
    print('finish_time:',time.time() - start_time)