import sqlite3
import traceback
import sys
import time
from datetime import datetime

def inputing():
	try:
	   sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
	   cursor = sqlite_connection.cursor()
	   result = """UPDATE objects_02 set branchs_delivery = 150 WHERE branchs_delivery =839 """
	   data = cursor.execute(result)
	  
	   sqlite_connection.commit()
	   
	   cursor.close()
	
	except sqlite3.Error as error:
		print("Ошибка при подключении к sqlite", error)
	finally:
	       if (sqlite_connection):
	       	sqlite_connection.close()
	       	print("Соединение с SQLite закрыто")


def main():
	       	inputing()
	       	
if __name__ == "__main__":
    main()