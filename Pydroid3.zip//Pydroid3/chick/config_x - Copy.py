import sqlite3
import traceback
import sys
import time
from datetime import datetime
start_time = time.time()

branches = (
"Omsk", "Perm", "Barnaul", "Gorno-altaysk", "Ufa", "Rubqovsk", "Nijniy- novgorod", "Stavropol", "Rostov-na-donu", "Saint-peterburg", "Orenburg")
incs = (
"looper", "parka", "vegas", "deli", "bliq_120", "bliq_48", "bliq_48q", "bliq_72", "ural", "baykal", "rio", "sezam", "rays",
"port", "baza", "baza_tripleks", "baza_630", "bliq_omega, termoregulator")


def branchs_delivery():
		while True:
			direction = int(input('chose direction: Omsk - 0, Perm - 1, Barnaul - 2, Gorno-altaysk - 3, Ufa -4, Rubqovsk - 5, Nijniy-novgorod - 6, Stavropol - 7, Rostov-na-donu - 8, Saint-Peterburg - 9, Orenburg - 10: '))
			direction = branches[direction]
			creaties_date = input('date_sending: ')
			branchs_delivery = int(input("enter sum: "))
			#vineline_money = int(input("enter vineline miney: "))
			try:
			 sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
			 cursor = sqlite_connection.cursor()
			 result = """SELECT count(*) from objects_02 WHERE creaties_date = ? and direction = ? """
			 data = cursor.execute(result, [creaties_date, direction])
			 print(data)
			 for i in data:
			 	branchs_delivery = branchs_delivery/int(i[0])
			 sqlite_connection.commit()
			 cursor.close()
			except sqlite3.Error as error:
				print("Ошибка при подключении к sqlite", error)
			finally:
			     	if (sqlite_connection):
			     		sqlite_connection.close()
			     		print("Соединение с SQLite закрыто")

			try:
			         		sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
			         		cursor = sqlite_connection.cursor()
			         		print("База данных подключена к SQLite")
			         		sqlite_insert_query = """UPDATE objects_02 set branchs_delivery = ? WHERE direction = ? and creaties_date = ? """
			         		t = cursor.execute(sqlite_insert_query, ([branchs_delivery, direction, creaties_date]))
			         		sqlite_connection.commit()
			         		print("Запись успешно вставлена ​​в таблицу sqlitedb_objects", cursor.rowcount)
			         		
			         		cursor.close()
			except sqlite3.Error as error:
			         		print("Не удалось вставить данные в таблицу sqlite")
			         		print("Класс исключения: ", error.__class__)
			         		print("Исключение", error.args)
			         		print("Печать подробноcтей исключения SQLite: ")
			         		exc_type, exc_value, exc_tb = sys.exc_info()
			         		print(traceback.format_exception(exc_type, exc_value, exc_tb))
			finally:
			         	   	if (sqlite_connection):
			         	   		sqlite_connection.close()
			         	   		print("Соединение с SQLite закрыто")
			print("price of one of inc: ", branchs_delivery)
			yes = input('if all press "N" :')
			if yes == 'N':
				break

def vineline_money():
		while True:
			direction = int(input('chose direction: Omsk - 0, Perm - 1, Barnaul - 2, Gorno-altaysk - 3, Ufa -4, Rubqovsk - 5, Nijniy-novgorod - 6, Stavropol - 7, Rostov-na-donu - 8, Saint-Peterburg - 9, Orenburg - 10: '))
			direction = branches[direction]
			creaties_date = input('date_of_delivering: ')
			vineline = int(input("enter sum: "))
			#vineline_money = int(input("enter vineline miney: "))
			try:
			 sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
			 cursor = sqlite_connection.cursor()
			 result = """SELECT count(*) from objects_02 WHERE creaties_date = ? and direction = ? """
			 data = cursor.execute(result, [creaties_date, direction])
			 print(data)
			 for i in data:
			 	vine_line = vineline/int(i[0])
			 sqlite_connection.commit()
			 cursor.close()
			except sqlite3.Error as error:
				print("Ошибка при подключении к sqlite", error)
			finally:
			     	if (sqlite_connection):
			     		sqlite_connection.close()
			     		print("Соединение с SQLite закрыто")

			try:
			         		sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
			         		cursor = sqlite_connection.cursor()
			         		print("База данных подключена к SQLite")
			         		sqlite_insert_query = """UPDATE objects_02 set vine_line = ? WHERE direction = ? and creaties_date = ? """
			         		t = cursor.execute(sqlite_insert_query, ([vine_line, direction, creaties_date]))
			         		sqlite_connection.commit()
			         		print("Запись успешно вставлена ​​в таблицу sqlitedb_objectsx", cursor.rowcount)
			         		
			         		cursor.close()
			except sqlite3.Error as error:
			         		print("Не удалось вставить данные в таблицу sqlite")
			         		print("Класс исключения: ", error.__class__)
			         		print("Исключение", error.args)
			         		print("Печать подробноcтей исключения SQLite: ")
			         		exc_type, exc_value, exc_tb = sys.exc_info()
			         		print(traceback.format_exception(exc_type, exc_value, exc_tb))
			finally:
			         	   	if (sqlite_connection):
			         	   		sqlite_connection.close()
			         	   		print("Соединение с SQLite закрыто")
			yes = input('if all press "N" :')
			if yes == 'N':
				break

def formations_of_object():
        total_amount = int(input("total amount: "))
        dict1 = {}
        amount_of_models_inc = int(input("amount of models inc: "))
        for i in range(amount_of_models_inc):
            product_name = int(input(
                "product_name: looper - 0 , parka - 1, vegas - 2, deli - 3, bliq120 - 4, bliq48 - 5, bliq48q - 6, bliq72 - 7, ural - 8, baykal - 9, rio - 10, sezam - 11, rays - 12, port - 13, baza - 14, baza_tripleks - 15, baza_630 - 16, bliq_omega -17, termoregulator -18, led_strip_30 - 19: "))
            print(incs[product_name])
            product = incs[product_name]
            purchase_price = int(input("purchase price: "))
            goods_prices = {incs[product_name]: purchase_price}
            dict1.update(goods_prices)
        orenburg_portage = int(input("orenburg portage: "))
        name_of_unwaiting_expense = input("name_of_unwaiting_expense: ")
        unwaiting_expense = int(input("sum of unwaiting expense: "))

        amount_of_direction = int(input("amount of direction: "))
        direction = {}
        for i in range(amount_of_direction):
            direction_name = int(input(
                "direction: Omsk - 0, Perm - 1, Barnaul - 2, Gorno-altaysk - 3, Ufa -4, Rubqovsk - 5, Nijniy-novgorod - 6, Stavropol - 7, Rostov-na-donu - 8, Saint-Peterburg - 9, Orenburg - 10: "))
            direction_name = branches[direction_name]
            portage_branch = int(input("portage branch: "))
            vine_line_portage = int(input("vine line portage: "))

            amount_of_model_of_inc = int(input("amount of model of inc: "))
            goods = {}
            for i in range(amount_of_model_of_inc):
                name_of_inc = int(input(
                    "name of inc: product_name: looper - 0 , parka - 1, vegas - 2, deli - 3, bliq120 - 4, bliq48 - 5, bliq48q - 6, bliq72 - 7, ural - 8, baykal - 9, rio - 10, sezam - 11, rays - 12, port - 13, baza - 14, baza_tripleks - 15, baza_630 - 16, bliq_omega -17, termoregulator - 18, led_strip_30 - 19: "))
                name_of_inc = incs[name_of_inc]
                amount_of_inc = int(input("amount of inc: "))
                goods_in = {name_of_inc: amount_of_inc}
                goods.update(goods_in)

            dict_a = {direction_name: {"portage_branch": portage_branch, "vine_line_portage": vine_line_portage,
                                       "goods": goods}}
            direction.update(dict_a)
            print(direction)

            data_one = {today: {"total_amount": total_amount, "goods_prices": dict1,
                                "expenses": {"orenburg_portage": orenburg_portage,
                                             name_of_unwaiting_expense: unwaiting_expense}, "direction": direction}}                                 
        
        print(data_one)
        creaties_date = today
        delivery_in_town = orenburg_portage / total_amount
        a = data_one[today]["direction"]
        print(a)
        p = list(a.keys())
        directions = p[0]

        for direction in p:
            goods = data_one[today]["direction"][direction]["goods"]
            for model, amount in goods.items():
                prime_cost = data_one[today]["goods_prices"][model]
                for i in range(amount):
                    retail_price = prime_cost + prime_cost * 0.1
                    print(model, direction, prime_cost, creaties_date, delivery_in_town)
                    try:
                        	sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
                        	cursor = sqlite_connection.cursor()
                        	print("База данных подключена к SQLite")
                        	sqlite_insert_query = """INSERT INTO objects_02(model, direction,  creaties_date, prime_cost, delivery_in_town)  VALUES  (?, ?, ?, ?, ?)"""
                        	date_sql = (model, direction, creaties_date, prime_cost, delivery_in_town)
                        	
                        	count = cursor.execute(sqlite_insert_query, date_sql)
                        	sqlite_connection.commit()
                        	
                        	print("Запись успешно вставлена ​​в таблицу sqlitedb_objects", cursor.rowcount)
                        	cursor.close()
                        	
                    except sqlite3.Error as error:
                        	print("Не удалось вставить данные в таблицу sqlite")
                        	print("Класс исключения: ", error.__class__)
                        	print("Исключение", error.args)
                        	print("Печать подробноcтей исключения SQLite: ")
                        	exc_type, exc_value, exc_tb = sys.exc_info()
                        	print(traceback.format_exception(exc_type, exc_value, exc_tb))
                        
                    finally:
                            if (sqlite_connection):
                            	sqlite_connection.close()
                            	print("Соединение с SQLite закрыто")


def sellings():
	direction = int(input('chose direction: Omsk - 0, Perm - 1, Barnaul - 2, Gorno-altaysk - 3, Ufa -4, Rubqovsk - 5, Nijniy-novgorod - 6, Stavropol - 7, Rostov-na-donu - 8, Saint-Peterburg - 9, Orenburg - 10: '))
	direction = branches[direction]
	try:
	   sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
	   cursor = sqlite_connection.cursor()
	   result = """SELECT direction, model,date_of_sale FROM objects_02 WHERE date_of_sale is NOT NULL and direction = ? ORDER BY date_of_sale"""
	   data = cursor.execute(result,[direction])
	   for i in data:
	   	print(f"{i[0]:>15} {i[1]:>8} {i[2]:>2}")
	   
	   sqlite_connection.commit()
	   
	   cursor.close()
	
	except sqlite3.Error as error:
		print("Ошибка при подключении к sqlite", error)
	finally:
	       if (sqlite_connection):
	       	sqlite_connection.close()
	       	print("Соединение с SQLite закрыто")


def aviability():
	total_amount = 0
	try:
	   sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
	   cursor = sqlite_connection.cursor()
	   result = """SELECT date_of_sale, direction, model, count(model) FROM objects_02 WHERE date_of_sale is NULL GROUP BY direction, model """
	   data = cursor.execute(result)
	   for i in data:
	   	print(f"{i[1]:>15}: {i[2]:>8}: {i[3]:>2} шт.")
	   	#print(f"{i[1]}: {i[2]} - {i[3]} шт.")
	   	total_amount = total_amount + i[3]
	   print(f"Всего инкубаторов - {total_amount} шт.")
	   
	   sqlite_connection.commit()
	   
	   cursor.close()
	
	except sqlite3.Error as error:
		print("Ошибка при подключении к sqlite", error)
	finally:
	       if (sqlite_connection):
	       	sqlite_connection.close()
	       	print("Соединение с SQLite закрыто")
	

def buying():
		while True:
			direction = int(input('chose direction: Omsk - 0, Perm - 1, Barnaul - 2, Gorno-altaysk - 3, Ufa -4, Rubqovsk - 5, Nijniy-novgorod - 6, Stavropol - 7, Rostov-na-donu - 8, Saint-Peterburg - 9, Orenburg - 10: '))
			direction = branches[direction]
			model = int(input('choose the products_name: looper - 0 , parka - 1, vegas - 2, deli - 3, bliq120 - 4, bliq48 - 5, bliq48q - 6, bliq72 - 7, ural - 8, baykal - 9, rio - 10, sezam - 11, rays - 12, port - 13, baza - 14, baza_tripleks - 15, baza_630 - 16, bliq_omega -17, termoregulator - 18, led_strip_30 - 19: '))
			model = incs[model]
			retail_price = int(input('retail_price: '))
			date_of_sale = input('date_of_sale: ')
			back_money = int(input('back_money: '))
			comment = input('comment ')
			n = int(input("repeats amount goods: "))
			#selling(direction, model, retail_price, date_of_sale, back_money, comment, n)
			yes = input('if all press "N" :')
			if yes == 'N':
				break
			
			for i in range(n):
			         	try:
			         		sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
			         		cursor = sqlite_connection.cursor()
			         		print("База данных подключена к SQLite")
			         		sqlite_insert_query = """UPDATE objects_02 set retail_price = ?, date_of_sale = ?, back_money = ?, comment = ? WHERE rowid  = (SELECT min(rowid) FROM objects_02 WHERE date_of_sale is NULL and direction = ? and model = ? )"""
			         		t = cursor.execute(sqlite_insert_query, (retail_price, date_of_sale, back_money, comment, direction, model))
			         		sqlite_connection.commit()
			         		print("Запись успешно вставлена ​​в таблицу sqlitedb_objectsx", cursor.rowcount)
			         		
			         		cursor.close()
			         	except sqlite3.Error as error:
			         		print("Не удалось вставить данные в таблицу sqlite")
			         		print("Класс исключения: ", error.__class__)
			         		print("Исключение", error.args)
			         		print("Печать подробноcтей исключения SQLite: ")
			         		exc_type, exc_value, exc_tb = sys.exc_info()
			         		print(traceback.format_exception(exc_type, exc_value, exc_tb))
			         	finally:
			         	   	if (sqlite_connection):
			         	   		sqlite_connection.close()
			         	   		print("Соединение с SQLite закрыто")
	
  	
def main():
	       	aviability()
	       	sellings()
	       	buying()
	       	
if __name__ == "__main__":
    main()