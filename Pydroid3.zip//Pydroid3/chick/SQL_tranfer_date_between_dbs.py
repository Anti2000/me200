import sqlite3
import traceback
import sys
from datetime import datetime

now = datetime.now()
print(now)


def tranfering_data_btw_tables():
    #conn = sqlite3.connect("sqlite_attemp_05.db")
    #cursor = conn.execute("SELECT * FROM sqlitedb_objects", )
    try:
            sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
            cursor = sqlite_connection.cursor()
            print("База данных подключена к SQLite")
            sqlite_insert_query = """INSERT INTO objects_02(model, direction, creaties_date, date_of_arrival, date_of_sale, retail_price, prime_cost, delivery_in_town, vine_line,object_life_time, comment)
SELECT model, direction, creaties_date, date_of_arrival, date_of_sale, prime_cost, delivery_in_town, vine_line, delivery_in_local_town, null, comment FROM sqlitedb_objects"""
            #date_sql = (id, model, direction, creaties_date, date_of_arrival, date_of_sale, retail_price, prime_cost, delivery_in_town, vine_line, comment)
            count = cursor.execute(sqlite_insert_query)
            sqlite_connection.commit()
            print("Запись успешно вставлена ​​в таблицу sqlitedb_objects", cursor.rowcount)
            cursor.close()
    except sqlite3.Error as error:
            print("Не удалось вставить данные в таблицу sqlite")
            print("Класс исключения: ", error.__class__)
            print("Исключение", error.args)
            print("Печать подробноcтей исключения SQLite: ")
            exc_type, exc_value, exc_tb = sys.exc_info()
            print(traceback.format_exception(exc_type, exc_value, exc_tb))
    finally:
            if (sqlite_connection):
                sqlite_connection.close()
                print("Соединение с SQLite закрыто")



tranfering_data_btw_tables()


print(now)
