import sqlite3
import traceback
import sys
import time
from datetime import datetime
start_time = time.time()

birthday = datetime.now()
print("bungo: ", birthday)


def searching():
	with open('ali_orders.txt', 'r', encoding='utf-8') as x:
		counter = counter_order = trek = trek_one = trek_two = trigger = description  = trigger_one = sum_of_order = trigger_two = alies_store = trigger_three = name_of_order = 0
		for i in x:
			counter = counter + 1
			#print(counter, i)
			if "Статус" in i:
				trigger = counter + 2
			if  trigger == counter:
				description = i
			if "Номер заказа" in i:
				name_of_order = i[14:-1]
				counter_order = counter_order + 1		
			if "Магазин" in i:
				trigger_two = counter + 1
			if trigger_two == counter:
				alies_store = i
			if "Подробности" in i:
				trigger_three = counter + 2
				trek_one = counter + 4
				trek_two = counter + 6
			if trigger_three == counter:
				trek = i 
			if trek_one == counter:
				trek_one = i
			if trek_two == counter:
				trek_two = i
			if "Общая сумма" in i:
				trigger_one = counter + 2
			if trigger_one == counter:
				if not "Статус" in i:
					sum_of_order = i
					print(f"number of order: {name_of_order}\ndescription: {description}amount of orders: {counter_order}\nsum of order: {sum_of_order}store: {alies_store} trek: {trek} trek_one: {trek_one} trek_two: {trek_two}")
					try:
				                    	                        	sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
				                    	                        	cursor = sqlite_connection.cursor()
				                    	                        	print("База данных подключена к SQLite")
				                    	                        	sqlite_insert_query = """INSERT INTO ali(birthday, name_of_order, description,  sum_of_order, alies_store, trek, trek_one,trek_two)  VALUES  (?, ?, ?, ?, ?, ?, ?, ?)"""
				                    	                        	date_sql = (birthday, name_of_order, description, sum_of_order, alies_store, trek, trek_one, trek_two)
				                    	                        	count = cursor.execute(sqlite_insert_query, date_sql)
				                    	                        	sqlite_connection.commit()
				                    	                        	print("Запись успешно вставлена ​​в таблицу sqlitedb_objects", cursor.rowcount)
				                    	                        	cursor.close()
					except sqlite3.Error as error:
				                    	print("Не удалось вставить данные в таблицу sqlite")
				                    	print("Класс исключения: ", error.__class__)
				                    	print("Исключение", error.args)
				                    	print("Печать подробноcтей исключения SQLite: ")
				                    	exc_type, exc_value, exc_tb = sys.exc_info()
				                    	print(traceback.format_exception(exc_type, exc_value, exc_tb))
					finally:
				                        	if (sqlite_connection):
				                        		sqlite_connection.close()
				                        		print("Соединение с SQLite закрыто")
				

def main():
	searching()

if __name__ == "__main__":
    main()
    print('finish_time: ', time.time() - start_time)