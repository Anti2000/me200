import time
from datetime import datetime
from config_x import aviability
from config_x import buying
from config_x import sellings
from config_x import  formations_of_object
from config_x import vineline_money
from config_x import branchs_delivery

# add player
#today = str(datetime.now())
today = time.strftime("%Y-%m-%d-%M-%s")
# pdb
# timeit
#round(t)

start_time = time.time()

def main():
	while True:
		try:
			command =input("enter command: aviability - 0, buying - 1, sellings - 2, sending - 3, vinelie_money - 4, branchs_delivery - 5, break - X: ")
			if command == "0":
				aviability()
			elif command == "1":
				buying()
			elif command == "2":
				sellings()
			elif command == "3":
				formations_of_object()
			elif command == "4":
				vineline_money()
			elif command == "5":
				branchs_delivery()
			elif command == "X":
				break
			#command = None
		except ex as error:
			print("incorrect command, try again")

if __name__ == "__main__":
    main()
    print('finish_time:', time.time() - start_time)