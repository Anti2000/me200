import sqlite3
import traceback
import sys
import time
from datetime import datetime
start_time = time.time()

def calculate_profit():
	profit = int(input("enter data: "))
	for_me = profit * 0.1
	Gods = profit * 0.2
	investment = profit * 0.70
	print("for me: ", for_me, "Gods: ", Gods, "investment: ", investment)
	try:
			 sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
			 cursor = sqlite_connection.cursor()
			 result = """SELECT direction, model, back_money, prime_cost, delivery_in_town, vine_line, branchs_delivery, date_of_sale from objects_02 WHERE date_of_sale is NOT NULL and back_money is NOT NULL """
			 data = cursor.execute(result)
			 all_profit = 0
			 #print(data)
			 for i in data:
			 	profit = i[2] - i[3] - i[4] - i[5] - i[6]
			 	print(all_profit, profit)
			 	all_profit = all_profit + profit
			 sqlite_connection.commit()
			 cursor.close()
	except sqlite3.Error as error:
				print("Ошибка при подключении к sqlite", error)
	finally:
			     	if (sqlite_connection):
			     		sqlite_connection.close()
			     		print("Соединение с SQLite закрыто")
	

def audit():
	try:
			 sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
			 cursor = sqlite_connection.cursor()
			 result = """SELECT direction, model from objects_02 WHERE date_of_sale is NOT NULL and retail_price is NULL or date_of_sale is NOT NULL and back_money is NULL"""
			 data = cursor.execute(result)
			 #print(data)
			 for i in data:
			 	print(i)
			 sqlite_connection.commit()
			 cursor.close()
	except sqlite3.Error as error:
				print("Ошибка при подключении к sqlite", error)
	finally:
			     	if (sqlite_connection):
			     		sqlite_connection.close()
			     		print("Соединение с SQLite закрыто")

start_time = time.time()

def main():
	#audit()
	calculate_profit()
	

if __name__ == "__main__":
    main()
    print('finish_time:', time.time() - start_time)