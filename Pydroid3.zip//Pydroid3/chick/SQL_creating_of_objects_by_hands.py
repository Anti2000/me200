import sqlite3
import traceback
import sys
from datetime import datetime

today = datetime.now()


def adding_of_data():
                    direction = 'Omsk'
                    model = 'looper'
                    count = 3
                    #date_of_arrival = "2022-04-13"
                    #date_of_sale = today
                    date_of_creation = "2022-05-13"
                    retail_price = 11920
                    delivery_in_town = 40
                    prime_cost = 6144
                    vine_line = 0
                    #branchs_delivery = 150
                    #selled_price = 0
                    #back_money_for_good = 0
                    #provit = 0
                    #comment = ''
                    for i in range(count):
                        try:
                        	sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
                        	cursor = sqlite_connection.cursor()
                        	print("База данных подключена к SQLite")
                        	sqlite_insert_query = """INSERT INTO objects_02(model, direction,  creaties_date, retail_price,  prime_cost, delivery_in_town, vine_line)  VALUES  (?, ?, ?, ?, ?, ?, ?)"""
                        	date_sql = (model, direction, date_of_creation, retail_price, prime_cost, delivery_in_town, vine_line)
                        	
                        	count = cursor.execute(sqlite_insert_query, date_sql)
                        	sqlite_connection.commit()
                        	
                        	print("Запись успешно вставлена ​​в таблицу sqlitedb_objects", cursor.rowcount)
                        	cursor.close()
                        	
                        except sqlite3.Error as error:
                        	print("Не удалось вставить данные в таблицу sqlite")
                        	print("Класс исключения: ", error.__class__)
                        	print("Исключение", error.args)
                        	print("Печать подробноcтей исключения SQLite: ")
                        	exc_type, exc_value, exc_tb = sys.exc_info()
                        	print(traceback.format_exception(exc_type, exc_value, exc_tb))
                        
                        finally:
                            if (sqlite_connection):
                            	sqlite_connection.close()
                            	print("Соединение с SQLite закрыто")


#def input_commands_and_info():
    


def main():
    adding_of_data()
    #input_commands_and_info()
    

if __name__ == "__main__":
    main()



