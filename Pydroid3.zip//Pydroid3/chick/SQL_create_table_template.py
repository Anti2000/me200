import sqlite3

try:
    sqlite_connection = sqlite3.connect('sqlite_attempt_05.db')
    sqlite_create_table_query = '''CREATE TABLE ali(
                                birthday datetime
                                
                                name_of_order  TEXT NOT NULL,
                                amount INTEGER NOT NULL,
                                date_of_arrival datetime,
                                date_of_sale datetime,
                                retail_price INTEGER, 
                                prime_cost INTEGER,
                                delivery_in_town INTEGER, 
                                vine_line INTEGER,
                                branchs_delivery INTEGER,
                                purchase_price INTEGER,
                                back_money INTEGER,
                                profit INTEGER,
                                object_life_time datetime,
                                comment TEXT);'''

    cursor = sqlite_connection.cursor()
    print("База данных подключена к SQLite")
    cursor.execute(sqlite_create_table_query)
    sqlite_connection.commit()
    print("Таблица SQLite создана")

    cursor.close()

except sqlite3.Error as error:
    print("Ошибка при подключении к sqlite", error)
finally:
    if (sqlite_connection):
        sqlite_connection.close()
        print("Соединение с SQLite закрыто")