from bs4 import BeautifulSoup
import requests as req
import datetime
import time

date = time.strftime("%d %b %Y")


difPrice = {}
prices = {}
oldPrise = {}


### RECIEVING DATA FROM "https://inkubator-inkubator.ru/price" ###
def recievData():
    data_site_norma = req.get("https://inkubator-inkubator.ru/price")
    soup_norma = BeautifulSoup(data_site_norma.text, 'html.parser')
    for i in range(6):
        item = soup_norma.find_all("div",
                                   style="width:700px; height:50px; line-height:50px; float:left; text-align: left; font-weight: bold; font-size: 25px")[
            i].text
        item = item.replace('\n', '')
        price = soup_norma.find_all("div",
                                    style="width:100px; height:50px; line-height:50px; float:right; text-align:right; font-size: 25px; font-weight: bold; color: #2a9f0a")[
            i].text
        price = price.replace('\r\n', '')
        prices.update({item: price})

    ### RECIEVING DATA FROM "http://www.pticevod.com/optovyi-prais.html" ###
    data_site_pticev = req.get("http://www.pticevod.com/optovyi-prais.html")
    soup_pticev = BeautifulSoup(data_site_pticev.text, 'html.parser')
    for link in soup_pticev.find_all('b'):
        if 'Инкубатор' in link.text:
            item = link.text
            flag = True
        if 'р.' in link.text and flag:
            price = link.text
            flag = False
        prices.update({item: price})

    return prices


def printTable(prices):
    print(f"{date}{'НАИМЕНОВА́НИЕ':>27}{'Старая цена':>12} {'Текущая цена':>10}")
    with open('price_inc.txt', 'r', encoding='utf-8') as inp:
        for i, y in zip(inp.readlines(), prices):
            item, price = i.strip().split(':')
            if price in prices[y]:
                print(f"{item:>37}{price:>12}-{prices[y]:<10}")
            else:
                difPrice.update({item: prices[y]})
                oldPrise.update({item: price})

    return difPrice, oldPrise


print()

def print_dif_price(*args):
    for i, y in zip(oldPrise, difPrice):
        print(f'Цена {i} изменилась c {oldPrise.get(i)} на {prices[y]}')


def write_price_file(*args):
    with open('price_inc.txt','w', encoding='utf-8') as out:
        for key, val in prices.items():
            out.write('{}:{}\n'.format(key, val))
    with open(timeStamped('price_inc.txt'), 'w', encoding='utf-8') as out:
        out.write("{}\n".format(date))
        for key, val in prices.items():
            out.write('{}:{}\n'.format(key, val))


def timeStamped(fname, fmt='%d %b %Y_{fname}'):
    return datetime.datetime.now().strftime(fmt).format(fname=fname)


def inputCommand():
    while True:

        recievData()
        printTable(prices)
        print_dif_price(difPrice, oldPrise)
        print("Введите команду 'e' для завершения работы,"
                         " команду 'r' для повтора или команду 'w' для записи цен в память")

        InputCommands = str(input("Ввод Команды:  "))

        if InputCommands == 'e':
            print('Программа завершена')
            break

        elif InputCommands == 'r':
            recievData()
            printTable(prices)
            print_dif_price(difPrice, oldPrise)

        elif InputCommands == 'w':
            print("Запись в файл сделано")
            write_price_file(prices, date)

        else:
            print("Ошибка!!! Это неверная команда. Попробуйте еще")


if __name__ == '__main__':
    inputCommand()

# function main: if __name__ == "__main__":
# write desktop of program, use functions and classes.
# know how i can write function for outputing of info.
# write funcion for writing data in file.
# output and writing the date.
#write expeption
