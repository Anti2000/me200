import sqlite3
 
conn = sqlite3.connect("TYSQL.sqlite") # или :memory: чтобы сохранить в RAM
#cursor = conn.cursor()
cursor = conn.execute("/*это коментарий */ SELECT cust_name FROM Customers WHERE cust_email is NULL",)

for row in cursor:
	print(f"{row}")
	#print(f' {row[0]: <10} {row[1] :^10} {row[2]}')
	#print(f' {row[0]: <20} {row[1] :>20} ')
	
	
#print(f'Цена {i} изменилась c {oldPrise.get(i)} на {prices[y]}')	
	
#cursor.execute("SELECT prod_name; FROM Products;")

# import sqlite3

#conn = sqlite3.connect('test.db')
#print "Opened database successfully";

#cursor = conn.execute("SELECT id, name, address, salary from COMPANY")
#for row in cursor:
#   print "ID = ", row[0]
#   print "NAME = ", row[1]
#   print "ADDRESS = ", row[2]
#   print "SALARY = ", row[3], "\n"

#print "Operation done successfully";
conn.close()