import json
#import time
import sqlite3
import traceback
import sys

# pdb
# timeit

from datetime import datetime

today = current_datetime = datetime.now()
print(current_datetime)

#today = str(datetime.now())
#today = time.strftime("%Y-%m-%d-%M-%s")
# print(today)

branches = (
"Omsk", "Perm", "Barnaul", "Gorno-altaysk, Ufa, Rubqovsk, Nijniy- novgorod, Stavropol, Rostov-na-donu, Saint-Peterburg")

note = input("date, town, abiability, status : ")


with open("log_branchs_aviab", "a", encoding = "utf8") as f:
	f.writelines(f" {note} \n ")

def writing_of_logs_aviab(self, data):
            while note  == None:
                print()
                direction_name = int(input("direction: Omsk - 0, Perm - 1, Barnaul - 2, Gorno-altaysk - 3, Ufa -4, Rubqovsk - 5, Nijniy-novgorod - 6, Stavropol - 7, Rostov-na-donu - 8, Saint-Peterburg - 9: "))
                note = input()




