import json
import time
#import datetime
from datetime import datetime
today = str(datetime.now())

fname = 'backup'

class Good:
  #list = [Omsk, Perm, barnaul, gorno-altaysk]
  #incs = [looper, parka, vegas, deli, bliq120, bliq48, bliq48q, bliq72, ural, baykal, rio, sezam, rays, port, baza, baza_tripleks, baza_630, bliq_omega]
  def __init__(self, name, age):
  	self.name = name
  	self.age = age
  def show_bd(self):
    			with open("BD_branches.json", "r", encoding = "utf8") as f:
    				data = json.load(f)
    				#print(data)
    				print(data["shipments"])
    				return data
  def shipments(self, data):
    		total_amount = int(input("total amount: "))
    		dict1 = {}
    		amount_of_models_inc = int(input("amount of models inc: "))
    		for i in range(amount_of_models_inc):
    			product_name = input("product_name: ")
    			purchase_price = int(input("purchase price: "))
    			goods_prices = {product_name:purchase_price}
    			dict1.update(goods_prices)
    		print("expenses:")
    		orenburg_portage = int(input("orenburg portage: "))
    		name_of_unwaiting_expense = input("name_of_unwaiting_expense: ")
    		unwaiting_expense = int(input("sum of unwaiting expense: "))
    		
    			
    			
    		amount_of_direction = int(input("amount of direction: "))
    		direction = {}
    		for i in range(amount_of_direction):
    			    	direction_name = input("direction: ")
    			    	portage_branch = int(input("portage branch: "))
    			    	vine_line_portage = int(input("vine line portage: "))   			    	
    			    	
    			    	
    			    	amount_of_model_of_inc = int(input("amount of model of inc: "))
    			    	goods = {}
    			    	for i in range(amount_of_model_of_inc):
    			    		name_of_inc = input("name of inc: ")
    			    		amount_of_inc = int(input("amount of inc: "))
    			    		goods_in = { name_of_inc : amount_of_inc }
    			    		goods.update(goods_in)
    			    		
    			    			
    			    	dict_a = {direction_name : { "portage_branch":portage_branch, "vine_line_portage":vine_line_portage, "goods":goods}}
    			    	direction.update(dict_a)
    			    	print(direction)
    			    	
    			    	
    			    	data_one = {today: {"total_amount":total_amount, "goods_prices":dict1, "expenses":{"orenburg_portage":orenburg_portage, name_of_unwaiting_expense:unwaiting_expense}, "direction":direction}}
    		#data_one.update(data)
    		print(data_one)
    		return data_one


  def writing_in_bd(self, data_one, data):
    			    			with open('BD_branches.json', 'w', encoding = 'utf8') as f:
    			    				data_two = data["shipments"]
    			    				data_two.update(data_one)
    			    				data["shipments"] = data_two
    			    				json_str = json.dumps(data, ensure_ascii=False)
    			    				f.write(json_str)



   
  def writing_backup(self, DATA, a):
        with open(a('backup.txt'), 'w', encoding='utf-8') as out:
        	out.write(DATA)
        	
  def timeStamped(self, fname, fmt='%Y-%m-%d-%M-%S_{fname}'):
  	return datetime.datetime.now().strftime(fmt).format(fname=fname)
    	
def input_commands():
	while True:
		print('\n1 - exit,  2 - show BD, 3 - shipments, 4 - show logs, P - posting, F - formation')
		input_com = str(input("inputing of command: "))
		
		if input_com == "1":
			break
		
		elif input_com == "2":
			g = Good("John", 36)
			data = g.show_bd()
			#a = g.timeStamped(fname)
			#print(a)
			#print(type(a))
			#g.writing_backup(data, a)
			
		elif input_com == "3":
			g = Good("John", 36)
			#g.show_bd()
			data = g.show_bd()
			
			
			#g.shipments()
			data_one = g.shipments(data)
			print("bing", data_one)
			g.writing_in_bd(data_one, data)
			
		elif input_com == "D":
			display_of_logs()
			
		elif input_com == "P":
			posting()
			
		elif input_com == "F":
			p1 = Good("John", 36)

def main():
	input_commands()
	

if __name__ == "__main__":
	main()
	

#print(d.get('key4'))
#	A13