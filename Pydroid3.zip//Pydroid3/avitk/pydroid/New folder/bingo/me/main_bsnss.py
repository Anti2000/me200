import os
import os.path
import time
from datetime import datetime
from datetime import timedelta, date
import math
import json
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

start_time = time.time()

# TO DO: adding comment
#map
#fliter
#listcomp
#genexps
#memory

today = time.strftime("%Y-%m-%d %H:%M")
print(today)
now = datetime.now()

class Deal:
	atr = "cv"
	
	def __init__(self, title: str, cat: str, oper: str, time: str) -> dict:
		self.title = title
		self.cat = cat
		self.oper = oper
		self.time = time
	
	def get_db_me(self):
			with open('me.json', 'r', encoding='utf-8') as f:
				dict_me = json.load(f)
			with open('me.json', 'r', encoding='utf-8') as f:
				str_me = f.read()
				db_me = (dict_me, str_me)
			return db_me
	
	def get_all_deals(self, d=[], curr_key=[]):
	       for k, v in d.items():
	           if isinstance(v, dict):
	           	yield from get_all_deals(v, curr_key + [k])
	           elif isinstance(v, list):
	           	for i in v:
	           		yield from get_all_deals(i, curr_key + [k])
	           elif isinstance (v, str):
	           	yield '.'.join(curr_key + [k] + [v])
	           else:
	           	#  v = list(v)
	           	#print(v)
	           	yield '.'.join(curr_key + [k])	
		
		
Base = Deal("buz", "0", "eat", "5")

#print("bingo", Deal.get_all_deals())
#print("School: ", Base.get_db_me())


def get_all_deals(d, curr_key=[]):
    for k, v in d.items():
        if isinstance(v, dict):
            yield from get_all_deals(v, curr_key + [k])
        elif isinstance(v, list):
            for i in v:
                yield from get_all_deals(i, curr_key + [k])
        elif isinstance (v, str):    	
        	yield '.'.join(curr_key + [k] + [v])
        else:
          #  v = list(v)
            #print(v)
            yield '.'.join(curr_key + [k])
            

def get_db_me():
	with open('me.json', 'r', encoding='utf-8') as f:
			dict_me = json.load(f)
	with open('me.json', 'r', encoding='utf-8') as f:
			str_me = f.read()
	db_me = (dict_me, str_me)
	return db_me	


def writing_deals(deals):
		with open('agenda_deals.txt', 'w', encoding='utf-8') as f:
			for count, deal in enumerate(deals):
				f.write(f'\n{deal}')


def corection_of_deals(content, del_deal, new_deal):
		writing_in_bd(content)
	
	
def writing_file(content):
		with open("me.json", "w") as outfile:
			outfile.write(content)


def inputing_days(intime):
		need_date = now + timedelta(days=int(intime))
		need_date = datetime.strftime(need_date, "%Y-%m-%d %H:%M")
		return need_date


def  taking_todays_deals(deals):
	amount = 0
	today_list = []
	for count, deal in enumerate(deals):
	   		list_deal = deal.split(".")
	   		date = list_deal[-1]
	   		today= date[-16:-6]
	   		today = datetime.strptime(today, "%Y-%m-%d")
	   		if today < now:
	   			amount += 1
	   			today_list.append(deal)
	return today_list


def sorted_by_daties(deals):
	deals.sort(key=lambda date: datetime.strptime(date[-16:],"%Y-%m-%d %H:%M"))
	return deals	
	

def sorted_by_category(deals):
				deals.sort(key=lambda category: category[-19:-18])
				matrix_deals = []
				matrix_deals = [[deal for deal in deals if deal[-19:-18] == str(category)] for category in range(8)]
				return matrix_deals
				

def times_defining(inputs_data, year = "23"):
	mounth = time.strftime("%m")
	day = time.strftime("%d")
	if len(inputs_data) > 4:
		day = inputs_data[4:6]
	if len(inputs_data) > 6:
		mounth = inputs_data[6:8]
	if len(inputs_data) > 8:
		year = inputs_data[-2:]
	hour = inputs_data[:2]
	minutes = inputs_data[2:4]	
	need_date = ("20" + year + "-" + mounth + "-" + day + " " + hour + ":" + minutes)
	need_time = datetime.strptime(need_date, "%Y-%m-%d %H:%M")
	return need_date
	
	
def get_old_deal(deal):
	deal = deal.split(".")
	param_deal = deal[-1]
	deal = deal[-2]
	old_deal = '"' + deal + '": "' + param_deal + '"'
	return old_deal
	
	
def get_updata_deal(deal, need_time):
	deal = deal.split(".")
	category = deal[-1]
	category = category.split(",")
	category = category[-2]
	deal = deal[-2]
	updata_deal = '"' + deal + '": "' + category + ', ' + need_time + '"'
	return updata_deal
	
	
def get_new_cat(deal, new_category):
	deal = deal.split(".")
	time = deal[-1]
	time = time.split(",")
	time = time[-1]
	deal = deal[-2]
	updata_deal = '"' + deal + '": "' + new_category + ',' + time + '"'
	print(updata_deal)
	return updata_deal
	
	
def replace_deal(content, old_deal, updata_deal):
	content = content.replace(old_deal, updata_deal)
	return content

		 
def edit_deal(deal):
		print(deal)
		new_deal = input("enter edit deal: ")
		deal = deal.split(".")
		category = deal[-1]
		time = deal[-1]
		category = category.split(",")
		category = category[-2]
		updata_deal = '"' + new_deal + '": "' + time + '"'
		return updata_deal

	
def get_report(deals):
	base = len(deals[0])
	important = len(deals[1])
	brain = len(deals[2])
	internet = len(deals[4])
	home = len(deals[5])
	travel = len(deals[6])
	phone = len(deals[3])
	arrow = len(deals[7])
	print(f"{'total deals: '}{len(deals)}|{'today deals: '} {len(deals)}|{'base: '}{base}|{'important: '}{important} {'brain: '}{brain}||{'phone: '}{phone}|{'internet: '} {internet}|{'travel: '}{travel}|{'arrow: '}{arrow}\n")


def writing_spec_deal():
		content = get_db_me()[1]
		spec_deal = input("enter spec. deal: ")
		category = "1"
		print(spec_deal)
		v = "\n}\n}"
		new_deal = ',\n"' + spec_deal + '": "' + category + ", " + today + '"\n}\n}'
		content = content.replace(v, new_deal)
		with open("me.json", "w") as outfile:
			outfile.write(content)

def writing_spec_dealx(content, category, spec_deal):
		 return ',\n"' + spec_deal + '": "' + category + ", " + today + '"\n}\n}'
		
	
def delete_deal(deal):
	deal = deal.split(".")
	del_deal = '"' + deal[-2] + '": "' + deal[-1] + '",'
	return del_deal
	
	
def get_three_deals(deals):
				deals = deals[1]
				three_deals = deals[0:10]
				return three_deals
	

def display_deals(deals, category = 1):
		for number, deal in enumerate(deals[category], 1):
			deal = deal.split(".")
			time = deal[-1]
			print(f"{number:2} {time[-5:]} {deal[-2]}")
			
			
def show_deal(deal):
			deal = deal.split(".")
			time = deal[-1]
			print(f"{time[-5:]} {deal[-2]}")


class Backuper:
					
			def __init__(self):
				self.name = None
				self.sender_address = "anatole.yakovlev@gmail.com"
			
			def email(self, file_loc:str, attach_file_name:str, mail_content:str, sender_address:str = "anatole.yakovlev@gmail.com", sender_pass:str ="tbunoakrikzyszdv", receiver_address:str = "anton.novikov.storage@gmail.com"):
				mail_content = mail_content + today
				
				try:
					print(f'{"sending of data"}')
					message = MIMEMultipart()
					message['From'] = sender_address
					message['To'] = receiver_address
					message['Subject'] = 'A backup mail sent by agandies app. It has an attachment. ' + today
					message.attach(MIMEText(mail_content, 'plain'))
					attach_file = open(file_loc, 'rb')
					payload = MIMEBase('application', 'octate-stream')
					payload.set_payload((attach_file).read())
					encoders.encode_base64(payload)
					payload.add_header('Content-Decomposition', 'attachment', filename=attach_file_name)
					message.attach(payload)
					session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
					session.starttls() #enable security
					session.login(sender_address, sender_pass) #login with mail_id and password
					text = message.as_string()
					session.sendmail(sender_address, receiver_address, text)
					session.quit()
					print("backup was sending")
				except Exception as Error:
					print(f"{'check internet connection'}")
					pass
					
			def create_need_dir(self):
				absolute_path = os.path.dirname(__file__)
				relative_path = "backup_files"
				full_path = os.path.join(absolute_path, relative_path)
				try:
					os.mkdir(full_path)
				except OSError as error:
						pass
			
			def backup(self, content, fname:str):
				self.create_need_dir()
				directory = './backup_files/'
				r = self.timeStamped(fname)
				filename = r
				file_path = os.path.join(directory, filename)
				if not os.path.isdir(directory):
					os.mkdir(directory)
				with open(file_path, "w", encoding='utf-8') as out:
					out.write(content)
			
			def timeStamped(self, fname, fmt='%Y-%m-%d %H %M_{fname}'):
			 return now.strftime(fmt).format(fname=fname)

						
def main():
	backuper = Backuper()
	backuper.email("me.json", "me", "bsnss")
	while True:
		deals = sorted_by_category(taking_todays_deals(sorted_by_daties([*get_all_deals(get_db_me()[0])])))
		get_report(deals)
		#get_three_deals(deals)
		display_deals(deals)
		inputs_data = input(f'\n\n{"ENTER data or command: @ - add new deal, or category: 0 - base, 1 - impotant or press enter, 2 - brain, 3 - phone, 4 - internet, 5 - home, 6 - travel, 7 - arrow: "}\n\n')
		if inputs_data == "@":
			writing_spec_deal()
			inputs_data = 1
		elif inputs_data == "":
			inputs_data = 1
		inputs_data = int(inputs_data)
		for deal in deals[inputs_data]:
			old_deal = get_old_deal(deal)
			show_deal(deal)
			inputs_data = input(f"\n{'ENTER THE CHACHING OF TIME OR THE CATEGORY IN MUNBERS OR OTHER COMMAND: @ - ADDING OF NEW DEAL, # - DELETING, $ - EDITING, ANY NUMBER FOR CHARCHING CATEGORY: '}\n")
			if inputs_data == "":
				continue
			content = get_db_me()[1]
			if len(inputs_data) >= 4:
				need_time = times_defining(inputs_data)
				updata_deal = get_updata_deal(deal, need_time)
			elif inputs_data == "@":
				spec_deal = input("ENTER SPEC. DEAL: ")
				old_deal = "\n}\n}"
				category = input(f"{'ENTER CATEGORY: '}")
				updata_deal = writing_spec_dealx(content, category, spec_deal)
			elif inputs_data == "#":
				updata_deal = ""
				old_deal = delete_deal(deal)
			elif inputs_data == "$":
				updata_deal = edit_deal(deal)
			valid_answers = {"0", "1", "2", "3", "4", "5", "6", "7"}
			if (user_answer := inputs_data) in valid_answers:
				new_category = str(inputs_data)
				updata_deal = get_new_cat(deal, new_category)
			content = replace_deal(content, old_deal, updata_deal)
			backuper.backup(content, "me")
			writing_file(content)
			
		print('finish_time:', time.time() - start_time)

if __name__ == "__main__":
	main()