groups_list = [["auto_oren", "id_post"], "auto_56"]
print(groups_list)

def main():
	while True:
		

if __main__ == "main":
	main()