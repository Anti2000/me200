import sqlite3


try:
    sqlite_connection = sqlite3.connect('REALITY.db')
    sqlite_create_table_query = '''CREATE TABLE reality(
                                date_of_publication datetime,
                                price INTEGER,
                                link TEXT,
                                phone TEXT,
                                location TEXT,
                                id_of_avito INTEGER,
                                pic INTEGER,
                                area INTEGER,
                                type_of_garage TEXT,
                                type_of_reality TEXT,
                                security TEXT,
                                heating TEXT,
                                sink TEXT,
                                water TEXT,
                                celler TEXT,
                                car_pit TEXT,
                                views INTEGER,
                                date_of_sale datetime,
                                cause_sale TEXT,
                                retail_price INTEGER,
                                name_of_cooperative TEXT,
                                comment TEXT);'''

    cursor = sqlite_connection.cursor()
    print("База данных подключена к SQLite")
    cursor.execute(sqlite_create_table_query)
    sqlite_connection.commit()
    print("Таблица SQLite создана")

    cursor.close()

except sqlite3.Error as error:
    print("Ошибка при подключении к sqlite", error)
finally:
    if (sqlite_connection):
        sqlite_connection.close()
        print("Соединение с SQLite закрыто")