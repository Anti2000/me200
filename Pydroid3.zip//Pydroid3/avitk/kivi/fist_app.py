import kivy.app

class TestApp(kivy.app. App):
	pass
	
app = TestApp ()
app.run()