import time
from datetime import datetime
import math
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

date = time.strftime("%Y-%m-%d %H:%M")
today = date
date_object_now = datetime.now()

class Money:
	THITHE = 0.15
	
	def calculate_of_benifit():
		invest_money = int(input('invest_money: '))
		proceeds = int(input('proceeds: '))
		start_invest_date = input('start invest date: ')
		finish_invest_date = 0
		diration_recoupment = 0
		tithe = 0
		banks_percentage = 0.55
		profit = proceeds - invest_money
		return profit			

class Backup_of_code:
	
	def data_to_email():
		try:
			mail_content = '''backup of monies_benifit_app ''' + date
			sender_address = "anatole.yakovlev@gmail.com"
			sender_pass = "tbunoakrikzyszdv"
			receiver_address = "antiohy@mail.ru"
			message = MIMEMultipart()
			message['From'] = sender_address
			message['To'] = receiver_address
			message['Subject'] = 'A backup mail sent by cars apl. It has an attachment. ' + date
			message.attach(MIMEText(mail_content, 'plain'))
			attach_file_name = 'config.py'
			attach_file = open(attach_file_name, 'rb')
			payload = MIMEBase('application', 'octate-stream')
			payload.set_payload((attach_file).read())
			encoders.encode_base64(payload)
			payload.add_header('Content-Decomposition', 'attachment', filename=attach_file_name)
			message.attach(payload)
			session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
			session.starttls() #enable security
			session.login(sender_address, sender_pass) #login with mail_id and password
			text = message.as_string()
			session.sendmail(sender_address, receiver_address, text)
			session.quit()
		except:
			print(f'{"check internet connection"}')

codies_backup = Backup_of_code

codies_backup.data_to_email()

benefit = Benefit
print(benefit.calculate_of_benifit())

#benefit = Benefit

#car.record_mantenance()