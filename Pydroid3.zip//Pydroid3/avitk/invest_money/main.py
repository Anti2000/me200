import time
from datetime import datetime
from config import q

today = time.strftime("%Y-%m-%d %H:%M")

start_time = time.time()

def main():

	while True:
		try:
			command =input("Choose category: filling petrol - 0, repair - 1, enter deal - 2, maintenance - 3, break - @: ")
			if command == "0":
				pass
			elif command == "1":
				pass
			elif command == "2":
				pass
			elif command == "3":
				pass
			elif command == "@":
				break
		except command as error:
			print(command)

if __name__ == "__main__":
    main()
    print('finish_time:', time.time() - start_time)