import json
import time
import datetime
#pdb
#timeit

#from datetime import datetime
##today = str(datetime.now())
today = time.strftime("%Y-%m-%d-%M-%s")
#print(today)


branches = ("Omsk", "Perm", "Barnaul", "Gorno-altaysk, Ufa, Rubqovsk, Nijniy- novgorod, Stavropol, Rostov-na-donu, Saint-Peterburg")
incs = ("looper", "parka", "vegas", "deli", "bliq120", "bliq48", "bliq48q", "bliq72", "ural", "baykal", "rio", "sezam", "rays", "port", "baza", "baza_tripleks", "baza_630", "bliq_omega")

class Product:
    
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def show_bd(self):
        with open("BD_branches.json", "r", encoding="utf8") as f:
            data = json.load(f)
            print(data)
            #print(data["shipments"])
            return data

    def shipments(self, data):
        total_amount = int(input("total amount: "))
        dict1 = {}
        amount_of_models_inc = int(input("amount of models inc: "))
        for i in range(amount_of_models_inc):
            product_name = int(input("product_name: looper - 0 , parka - 1, vegas - 2, deli - 3, bliq120 - 4, bliq48 - 5, bliq48q - 6, bliq72 - 7, ural - 8, baykal - 9, rio - 10, sezam - 11, rays - 12, port - 13, baza - 14, baza_tripleks - 15, baza_630 - 16, bliq_omega -17: "))
            print(incs[product_name])
            #product_name = input("product_name: ")
            purchase_price = int(input("purchase price: "))
            goods_prices = {incs[product_name]: purchase_price}
            dict1.update(goods_prices)
        print("expenses:")
        orenburg_portage = int(input("orenburg portage: "))
        name_of_unwaiting_expense = input("name_of_unwaiting_expense: ")
        unwaiting_expense = int(input("sum of unwaiting expense: "))

        amount_of_direction = int(input("amount of direction: "))
        direction = {}
        for i in range(amount_of_direction):
            direction_name = int(input("direction: Omsk - 0, Perm - 1, Barnaul - 2, Gorno-altaysk - 3, Ufa -4, Rubqovsk - 5, Nijniy-novgorod - 6, Stavropol - 7, Rostov-na-donu - 8, Saint-Peterburg - 9: "))
            portage_branch = int(input("portage branch: "))
            vine_line_portage = int(input("vine line portage: "))

            amount_of_model_of_inc = int(input("amount of model of inc: "))
            goods = {}
            for i in range(amount_of_model_of_inc):
                name_of_inc = int(input("name of inc: product_name: looper - 0 , parka - 1, vegas - 2, deli - 3, bliq120 - 4, bliq48 - 5, bliq48q - 6, bliq72 - 7, ural - 8, baykal - 9, rio - 10, sezam - 11, rays - 12, port - 13, baza - 14, baza_tripleks - 15, baza_630 - 16, bliq_omega -17"))
                amount_of_inc = int(input("amount of inc: "))
                goods_in = {name_of_inc: amount_of_inc}
                goods.update(goods_in)

            dict_a = {direction_name: {"portage_branch": portage_branch, "vine_line_portage": vine_line_portage,
                                       "goods": goods}}
            direction.update(dict_a)
            print(direction)

            data_one = {today: {"total_amount": total_amount, "goods_prices": dict1,
                                "expenses": {"orenburg_portage": orenburg_portage,
                                             name_of_unwaiting_expense: unwaiting_expense}, "direction": direction}}
        # data_one.update(data)
        print(data_one)
        return data_one

    def writing_in_bd(self, data_one, data):
        with open('BD_branches.json', 'w', encoding='utf8') as f:
            data_two = data["shipments"]
            data_two.update(data_one)
            data["shipments"] = data_two
            json_str = json.dumps(data, ensure_ascii=False)
            f.write(json_str)
            data_three = data
            return  data_three

    def writing_backup(self, data_three):
        with open(self.time_stamped('backup.txt'), 'w', encoding='utf-8') as out:
            json_str = json.dumps(data_three, ensure_ascii=False)
            out.write(json_str)

    def time_stamped(self, fname, fmt='%Y-%m-%d-%M-%S_{fname}'):
        return datetime.datetime.now().strftime(fmt).format(fname=fname)
        
    def formations_of_object(self, data):
    	name = "total_amount"
    	r = data["shipments"]
    	f = list(r.keys())
    	shipments = f[0]
    	q = data["shipments"][shipments]["total_amount"]
    	a = data["shipments"][shipments]["direction"]
    	p = list(a.keys())
    	directions = p[0]
    	for town in p:
    		print(town)
    	goods = data["shipments"][shipments]["direction"][directions]["goods"]
    	print("search: ", goods)
    	for name, amount in goods.items():
    		for i in range(amount):
    			print({"name": name, "direction": directions, "date_of_formation":shipments,"date_of_arrival":"","date_of_sale":"","retail_price":"","prime_cost":"","delivery_in_town":"","vine_line":"","delivery_in_local_town":""})
    		
#{"name":"looper","dates?:{"birthday":"2022-01-01",date_of_arrival":2022-01-07?,?date_of_sale":?2022-01-15?, "retail_price":10000},"appurtenance":"ufa"},"purchase_price":7000,"prime_cost":6000,vine_line":600, earnings_of branch:?, amount_of_return:?, debt:?, date_of_return:?, returned_money:?, expected_profit:?, factual_profit:?} first cost, prime cost}  		
    		
    		

def input_commands():
    while True:
        print('\n1 - exit,  2 - show BD, 3 - shipments, 4 - show logs, P - posting, F - formation')
        input_com = str(input("inputing of command: "))

        if input_com == "1":
            break

        elif input_com == "2":
            g = Product("John", 36)
            data = g.show_bd()

        elif input_com == "3":
            # g.show_bd()
            data = g.show_bd()

            # g.shipments()
            data_one = g.shipments(data)
            data_three = g.writing_in_bd(data_one, data)
            print("bingo", data_three)
            a = g.time_stamped(fname)
            g.writing_backup(data_three)

        elif input_com == "D":
            display_of_logs()

        elif input_com == "P":
            posting()

        elif input_com == "F":
            p1 = Product("John", 36)


def main():
    g = Product("John", 36) 
    g.formations_of_object(g.show_bd())
    input_commands()


if __name__ == "__main__":
    main()

# print(d.get('key4'))
#	A13
