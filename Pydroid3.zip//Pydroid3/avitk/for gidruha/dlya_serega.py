restor_pot = float(input("сопротивление потенциометра: "))
om_150 = float(input("сопротивление при 150: "))
om_180 = float(input("сопротивление при 180: "))
om_190 = float(input("сопротивление при 190: "))
pressure_150 = float(input("давление при 150: "))
pressure_180 = float(input("давление при 180: "))
pressure_190 = float(input("давление при 190: "))
p_0 = float(input(" Р=0:"))
p_50 = float(input("Р=50: "))
resistor_of_kabel = 0.15

R_ish_150 = ((om_150 - resistor_of_kabel)*100)/restor_pot

R_ish_180 = ((om_180 - resistor_of_kabel)*100)/restor_pot

R_ish_190 = ((om_190 - resistor_of_kabel)*100)/restor_pot


lamda_150 = ((50*(R_ish_150 - p_0)) / (p_50 - p_0)) - pressure_150
lamda_180 = ((50*(R_ish_180 - p_0)) / (p_50 - p_0)) - pressure_180
lamda_190 = ((50*(R_ish_190 - p_0)) / (p_50 - p_0)) - pressure_190

print("∆ P150=",lamda_150)
print("∆ P180=", lamda_180)
print("∆ P190=", lamda_190)
proverka = lamda_190 - lamda_150
if proverka < 4 or proverka == 4:
	print("Условие верно, движок прошел. ∆ = ", proverka)
else:
	print("Движок не прошел")


