
import time
from datetime import datetime
from datetime import timedelta, date
import math
import json
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# TO DO: timeit, except error on adding spec deal, add function of deleteling deals, adding days, bug with stand up date hair month, dont charge category, adding comment


today = time.strftime("%Y-%m-%d %H:%M")
print(today)
now = datetime.now()
current_week = time.strftime("%V")


current_week = current_week.center(46,"*")
print(current_week)


def get_all_deals(d, curr_key=[]):
    for k, v in d.items():
        if isinstance(v, dict):
            yield from get_all_deals(v, curr_key + [k])
        elif isinstance(v, list):
            for i in v:
                yield from get_all_deals(i, curr_key + [k])
        elif isinstance (v, str):    	
        	yield '.'.join(curr_key + [k] + [v])
        else:
          #  v = list(v)
            #print(v)
            yield '.'.join(curr_key + [k])
            

def get_db_me_x():
	with open('me.json', 'r') as f:
			dict_me = json.load(f)
	with open('me.json', 'r') as f:
			str_me = f.read()
	db_me = (dict_me, str_me)
	return db_me	


def writing_deals(deals):
		with open('agenda_deals.txt', 'w', encoding='utf-8') as f:
			for count, deal in enumerate(deals):
				f.write(f'\n{deal}')

  		
def replace_datiest(deals, sum = 0, old_category = 0):
	content = get_db_me_x()[1]
	choose_cat = int(enter_category())
	for count, deal in enumerate(deals):
		xdeal = deal.split(".")
		ancor = xdeal[-2]
		param_deal = xdeal[-1]
		list_1 = param_deal.split(",")
		date = list_1[-1].strip()
		xdate = date
		old_category = new_category = list_1[0]		
		date = datetime.strptime(date, "%Y-%m-%d %H:%M")
	#	if date < now  and int(old_category) == choose_cat:
		if int(old_category) == choose_cat:
		  			sum += 1
		  			display_deals(sum, deal, ancor, xdate)
		  			input_data =  input(f'{"ENTER TIME OR DAYS or charge category: "}')
		  			if len(input_data) > 0:
		  				if input_data == "#":
		  					new_category = str(enter_category())
		  				need_date = str(inputing(input_data, deal))
		  				del_deal = ('"'+ ancor + '": "' + old_category + ", " + xdate + '"')
		  				new_deal = ('"' + ancor + '": "' + new_category + ", " + need_date + '"')
		  				
		  				content = replace_deal(content, del_deal, new_deal)
		  			writing_file(content)
		  			

def delete_deal(del_deal):
	content = get_db_me_x()[1]
	print("test", del_deal)
	clear_space = ""
	content = replace_deal(content, del_deal, clear_space)
	return content

def replace_deal(content, del_deal, new_deal):
	return content.replace(del_deal, new_deal)


def writing_spec_deal():
		content = get_db_me_x()[1]
		spec_deal = input("enter spec. deal: ")
		category = "1"
		print(spec_deal)
		v = "\n}\n}"
		new_deal = ',\n"' + spec_deal + '": "' + category + ", " + today + '"\n}\n}'
		content = content.replace(v, new_deal)
		with open("me.json", "w") as outfile:
			outfile.write(content)


def corection_of_deals(content, del_deal, new_deal):
		writing_in_bd(content)
	
	
def writing_file(content):
		with open("me.json", "w") as outfile:
			outfile.write(content)
			backup(content)


def inputing_days(intime):
		need_date = now + timedelta(days=int(intime))
		need_date = datetime.strftime(need_date, "%Y-%m-%d %H:%M")
		return need_date
		

def inputing_date(intime):
	size_of_data = len(intime)
	mounth = time.strftime("%m")
	day = time.strftime("%d")
	year = "23"
	if size_of_data > 4:
		day = intime[4:6]
	if size_of_data > 6:
		mounth = intime[6:8]
	if size_of_data > 7:
		year = intime[-2:]
	hour = intime[:2]
	minutes = intime[2:4]	
	need_date = ("20" + year + "-" + mounth + "-" + day + " " + hour + ":" + minutes)
	print("x", need_date)
	need_timex = datetime.strptime(need_date, "%Y-%m-%d %H:%M")
	return need_date

				
def inputing(intime, deal):
	try:
		intimies_six = len(intime)
		if intime == "@":
			writing_spec_deal()
		elif intime == "&":
			xdeal = deal.split(".")
			ancor = xdeal[-2]
			param_deal = xdeal[-1]
			del_deal = '"' + ancor + '": "' + param_deal + '",'
			content = delete_deal(del_deal)
			with open("me.json", "w") as outfile:
				outfile.write(content)
		#	writing_in_bd(content)
		elif intime == "$":
			json_object = get_db_me()
			deals = [*get_all_deals(json_object)]
			sorted_deal = sorted_by_daties(deals)
			display_deals(sorted_deal)
		elif int(intime) < 3:
			need_date = inputing_days(intime)
			print("x", need_date)
		else:
					need_date = inputing_date(intime)
		
	except Exception as Error:
		print(Error)
		need_date = now
		need_date = datetime.strftime(need_date, "%Y-%m-%d %H:%M")
	
	return need_date	
	

def  taking_todays_deals(deals):
	amount = 0
	new_list = []
	for count, deal in enumerate(deals):
	   		list_deal = deal.split(".")
	   		date = list_deal[-1]
	   		today= date[-16:-6]
	   		today = datetime.strptime(today, "%Y-%m-%d")
	   		now = datetime.strptime("2025-12-31", "%Y-%m-%d")
	   		if today < now:
	   			amount += 1
	   			new_list.append(deal)

	return new_list


def sorted_by_daties(deals):
	deals.sort(key=lambda date: datetime.strptime(date[-16:],"%Y-%m-%d %H:%M"))#, reverse = True)
		
	return deals	
	

def data_to_email():
		print("bingo_internet")
		try:
			print(f'{"sending of data"}')
			mail_content = '''backup of cars app ''' + today
			sender_address = "anatole.yakovlev@gmail.com"
			sender_pass = "tbunoakrikzyszdv"
			receiver_address = "antiohy@mail.ru"
			message = MIMEMultipart()
			message['From'] = sender_address
			message['To'] = receiver_address
			message['Subject'] = 'A backup mail sent by agandies app. It has an attachment. ' + today
			message.attach(MIMEText(mail_content, 'plain'))
			#attach_file_name = name_of_backup
			attach_file = open("me.json", 'rb')
			payload = MIMEBase('application', 'octate-stream')
			payload.set_payload((attach_file).read())
			encoders.encode_base64(payload)
			payload.add_header('Content-Decomposition', 'attachment', filename=attach_file_name)
			message.attach(payload)
			session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
			session.starttls() #enable security
			session.login(sender_address, sender_pass) #login with mail_id and password
			text = message.as_string()
			session.sendmail(sender_address, receiver_address, text)
			session.quit()
			print("backup was sending")
		except:
			print(f"{'check internet connection'}")


def backup(content):
        with open(timeStamped('price_inc.txt'), 'w', encoding='utf-8') as out:
        	out.write(content)


def timeStamped(fname, fmt='%Y-%m-%d %H %M_{fname}'):
    fname = "me"
    return now.strftime(fmt).format(fname=fname)


def enter_category():
	return input(f"{'enter category: 0 - base, 1 - impotant, 2 - brain, 3 - phone, 4 - internet, 5 - home, 6 - travel, 7 - arrow: '}")
	
	
def get_report():
	json_object = get_db_me_x()[0]
#	json_object = get_db_me()
	deals = [*get_all_deals(json_object)]
	sorted_deal = sorted_by_daties(deals)
	dealz = taking_todays_deals(sorted_deal)
	print(f"{'total deals: '}{len(deals)}  || {'today deals: '}{len(dealz)}")


def display_deals(count = None, deals = None, ancor = None, date = None):
	print(f"\n{deals}")
	print(f"{count} {ancor : <34}{date[-5:] : >10}")

	

#def display_deals_x(deals = None, ancor = None, date = None) #count = None:
#	print(f"\n{deals}")
#	print(f"{count} {ancor : <34}{date[-5:] : >10}")
				
				
def main():
	data_to_email()
	while True:
		
		
		#new order
	#	deals = taking_todays_deals(sorted_by_daties([*get_all_deals(get_db_me_x()[0])]))
	#	display_deals(deals)
	#	print(deals)
#		input()
		
		get_report()
		deals = taking_todays_deals(sorted_by_daties([*get_all_deals(get_db_me_x()[0])]))
		replace_datiest(deals)
		writing_deals(deals)
		
		
		


main()


#	print(f"{'FIVE TIMEBLOCK':^50}")
#map
#fliter
#listcomp
#genexps
#memory
#question = "Will you use the walrus operator?"
#valid_answers = {"yes", "Yes", "y", "Y", "no", "No", "n", "N"}


    
#while (user_answer := input(f"\n{question} ")) not in #valid_answers:
#    print(f"Please answer one of {', '.join(valid_answers)}")

# if any((witness := city).startswith("H") for city in cities):
#...     print(f"{witness} starts with H")
#... else:
#*...     print("No city name starts with H")

#Houston starts with H



#question = "Will you use the walrus operator?"
#valid_answers = {"yes", "Yes", "y", "Y", "no", "No", "n", "N"}

#user_answer = input(f"\n{question} ")
#while user_answer not in valid_answers:
#    print(f"Please answer one of {', '.join(valid_answers)}")
  #  user_answer = input(f"\n{question} ")
    
#while (user_answer := input(f"\n{question} ")) not in valid_answers:
 #   print(f"Please answer one of {', '.join(valid_answers)}")