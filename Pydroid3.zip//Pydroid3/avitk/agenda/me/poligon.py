import csv

from collections import defaultdict
from decimal import Decimal
from typing import List, Union

with open('/files/catalog_2.csv') as file:
    reader = csv.DictReader(file)
    products = [row for row in reader]


class TransactionReport(defaultdict):
    def init(self, *args, **kwargs):
        super(TransactionReport, self).init(TransactionReport, *args, **kwargs)

    def repr(self):
        return repr(dict(self))


transaction_report = TransactionReport()

for product in products:
    date = product['date'].rsplit('-', 1)[0]
    type_of_operation = product['type']
    shop = product['shop']
    category = product['category']
    name = product['name']
    price = float(product['price'])
    amount = int(product['amount'])
    transaction_report[type_of_operation][shop][category][name].setdefault(date, 0)
    transaction_report[type_of_operation][shop][category][name][date] += round(amount * Decimal(price), 2)

for transaction_types, shops in transaction_report.items():
    for shop, categories in shops.items():
        for category, products in categories.items():
            for product, monthly_cost in products.items():
                cost_of_goods_per_year = sum(monthly_cost.values())
                monthly_cost['итог'] = cost_of_goods_per_year


def get_total_cost_for_each_month(monthly_prices: List[dict]) -> dict:
    cost_by_months = defaultdict(int)

    for monthly_cost in monthly_prices:
        for month, cost in monthly_cost.items():
            cost_by_months[month] += cost

    return dict(sorted(cost_by_months.items()))


for transaction_types, shops in transaction_report.items():
    for shop, categories in shops.items():
        for category, products in categories.items():
            monthly_cost_by_category = get_total_cost_for_each_month(products.values())
            products['monthly_cost_by_category'] = monthly_cost_by_category


def find_value_by_key(key: str, obj: dict) -> Union[float, str]:
    if key in obj:
        return obj[key]
    for k, v in obj.items():
        if isinstance(v, TransactionReport):
            result = find_value_by_key(key, v)
            if result:
                return result


def get_monthly_cost_for(key: str, items: List[dict]) -> List[dict]:
    return [find_value_by_key(key, category) for category in items]


for transaction_types, shops in transaction_report.items():
    for shop, categories in shops.items():
        expenses_of_each_category = get_monthly_cost_for('monthly_cost_by_category', categories.values())
        monthly_costs_for_store = get_total_cost_for_each_month(expenses_of_each_category)
        categories['monthly_costs_for_store'] = monthly_costs_for_store

for transaction_types, shops in transaction_report.items():
    monthly_stores_expenses = get_monthly_cost_for('monthly_costs_for_store', shops.values())
    monthly_cost_of_transaction_type = get_total_cost_for_each_month(monthly_stores_expenses)
    shops['monthly_cost_by_category'] = monthly_cost_of_transaction_type

total_monthly_cost = get_total_cost_for_each_month(
    get_monthly_cost_for('monthly_cost_by_category', transaction_report.values()))
transaction_report['total_monthly_cost'] = total_monthly_cost


def serialize(obj: dict, tabs=0):
    result = []
    pref = '    ' * tabs
    for k, v in obj.items():
        if isinstance(v, dict):
            result += [pref + str(k)]
            result += [serialize(v, tabs + 1)]
        else:
            result += [pref + str(k) + ' ' + str(v)]
    return '\n'.join(result)


months = ['янв 2021', 'фев 2021', 'мар 2021', 'апр 2021', 'май 2021', 'июн 2021', 'июл 2021',
          'авг 2021', 'сен 2021', 'окт 2021', 'ноя 2021', 'дек 2021', 'итог']

result = serialize(transaction_report)
print('\t' * 9, *months, sep='    ', )
print(result)