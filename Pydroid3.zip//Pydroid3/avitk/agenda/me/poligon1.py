import time
from datetime import datetime
from datetime import timedelta, date
import math
import json
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# TO DO: timeit

today = time.strftime("%Y-%m-%d %H:%M")
print(today)
now = datetime.now()
current_week = time.strftime("%V")


def get_all_deals(d, curr_key=[]):
    for k, v in d.items():
        if isinstance(v, dict):
            yield from get_all_deals(v, curr_key + [k])
        elif isinstance(v, list):
            for i in v:
                yield from get_all_deals(i, curr_key + [k])
        elif isinstance (v, str):    	
        	yield '.'.join(curr_key + [k] + [v])
        else:
          #  v = list(v)
            #print(v)
            yield '.'.join(curr_key + [k])
            

def get_db_me():
		with open('me.json', 'r') as openfile:
			return json.load(openfile)


def writing_deals(deals):
		with open('agenda_deals.txt', 'w', encoding='utf-8') as f:
			for count, deal in enumerate(deals):
				f.write(f'\n{deal}')
    		
    		
def replace_datiest(deals):
	sum = 0
	with open("me.json", "r") as f:
		content = f.read()
	for count, deal in enumerate(deals):
		xdeal = deal.split(".")
		ancor = xdeal[-2]
		date = xdeal[-1]
		date = datetime.strptime(date, "%Y-%m-%d %H:%M")
		if date < now:
		  			sum += 1
		  			print(sum, deal)
		  			cor_deals = ('"' + ancor + '": "' + xdeal[-1] + '"')
		  			need_date = str(inputing())
		  			deal = ('"' + ancor + '": "' + need_date + '"')
		  			print(deal)
		  			content = content.replace(cor_deals, deal)
		  			writing_file(content)
		
		
def writing_file(content):
		with open("me.json", "w") as outfile:
			outfile.write(content)
			backup(content)
		
		
def inputing():
	try:
		data = input(f'{"enter need time: "}')
		size_of_data = len(data)
		mounth = time.strftime("%m")
		day = time.strftime("%d")
		year = "22"
		if size_of_data > 4:
			day = data[4:6]
		if size_of_data > 6:
			mounth = data[6:8]
		if size_of_data > 7:
			year = data[-2:]
		xhour = (data[:2])
		xminutes = (data[2:4])
#		need_date = now  + timedelta(minutes=need_time)		
		need_date = ("20" + year + "-" + mounth + "-" + day + " " + xhour + ":" + xminutes)
		date = datetime.strptime(need_date, "%Y-%m-%d %H:%M")
		
	except Exception as Error:
		print(Error)
		need_date = now
		need_date = datetime.strftime(need_date, "%Y-%m-%d %H:%M")
	
	return need_date	
	

def  taking_todays_deals(deals):
	amount = 0
	new_list = []
	for count, deal in enumerate(deals):
	   		list_deal = deal.split(".")
	   		date = list_deal[-1]
	   		today= date[:10]
	   		today = datetime.strptime(today, "%Y-%m-%d")
	   		if today < now:
	   			amount += 1
	   			new_list.append(deal)
	   			print(f"{amount} {deal}")
	   			print(f"{list_deal[-2] : <36}{date[-5:] : >10}")
	   			print() 

	return new_list


def sorted_by_daties(deals):
	sum = 0
	deals.sort(key=lambda date: datetime.strptime(date[-16:], "%Y-%m-%d %H:%M"), reverse = True)
		
	return deals	
	

def data_to_email():
		print("bingo_internet")
		try:
			print(f'{"sending of data"}')
			mail_content = '''backup of cars app ''' + today
			sender_address = "anatole.yakovlev@gmail.com"
			sender_pass = "tbunoakrikzyszdv"
			receiver_address = "antiohy@mail.ru"
			message = MIMEMultipart()
			message['From'] = sender_address
			message['To'] = receiver_address
			message['Subject'] = 'A backup mail sent by agandies app. It has an attachment. ' + today
			message.attach(MIMEText(mail_content, 'plain'))
			#attach_file_name = name_of_backup
			attach_file = open("me.json", 'rb')
			payload = MIMEBase('application', 'octate-stream')
			payload.set_payload((attach_file).read())
			encoders.encode_base64(payload)
			payload.add_header('Content-Decomposition', 'attachment', filename=attach_file_name)
			message.attach(payload)
			session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
			session.starttls() #enable security
			session.login(sender_address, sender_pass) #login with mail_id and password
			text = message.as_string()
			session.sendmail(sender_address, receiver_address, text)
			session.quit()
			print("backup was sending")
		except:
			print(f"{'check internet connection'}")


def backup(content):
        print("bingo_backup")
        with open(timeStamped('price_inc.txt'), 'w', encoding='utf-8') as out:
        	out.write(content)

def timeStamped(fname, fmt='%Y-%m-%d %H %M_{fname}'):
    fname = "me"
    return now.strftime(fmt).format(fname=fname)
    

def writing_spec_deal():
		with open("me.json", "r") as f:
			content = f.read()
		spec_deal = input("enter spec. deal: ")
		#spec_deal = (spec_deal + ": " + today)
		print(spec_deal)
		g = spec_deal
		v = "\n}\n}"
		f = ',\n"' + g + '": "' + today + '"\n}\n}'
		content = content.replace(v, f)
		with open("me.json", "w") as outfile:
			outfile.write(content)


def main():
	data_to_email()
	while True:
		taking_todays_deals(sorted_by_daties([*get_all_deals(get_db_me())]))
			
		command = input("inter command: ")
		if command == "B":
			break
		elif command == "@":
			writing_spec_deal()			
		json_object = get_db_me()
		deals = [*get_all_deals(json_object)]
		sorted_deal = sorted_by_daties(deals)
		dealz = taking_todays_deals(sorted_deal)
		replace_datiest(dealz)
		writing_deals(deals)


main()


#	print(f"{'FIVE TIMEBLOCK':^50}")
#map
#fliter
#listcomp
#genexps
#memory
#question = "Will you use the walrus operator?"
#valid_answers = {"yes", "Yes", "y", "Y", "no", "No", "n", "N"}


    
#while (user_answer := input(f"\n{question} ")) not in #valid_answers:
#    print(f"Please answer one of {', '.join(valid_answers)}")

# if any((witness := city).startswith("H") for city in cities):
#...     print(f"{witness} starts with H")
#... else:
#*...     print("No city name starts with H")

#Houston starts with H



#question = "Will you use the walrus operator?"
#valid_answers = {"yes", "Yes", "y", "Y", "no", "No", "n", "N"}

#user_answer = input(f"\n{question} ")
#while user_answer not in valid_answers:
#    print(f"Please answer one of {', '.join(valid_answers)}")
  #  user_answer = input(f"\n{question} ")
    
#while (user_answer := input(f"\n{question} ")) not in valid_answers:
 #   print(f"Please answer one of {', '.join(valid_answers)}")