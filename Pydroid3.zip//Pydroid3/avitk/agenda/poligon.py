d = {
"Name1": {
        "NNum": "11",
        "Node1": {
            "SubNodeA": "Thomas",
            "SubNodeB": "27"
        },
        "Node2": {
            "SubNodeA": "ZZZ",
            "SubNodeD": "XXX",
            "SubNodeE": "r"
        },
        "Node3": {
                "child1": 11,
                "child2": {
                    "grandchild": {
                        "greatgrandchild1": "Rita",
                        "greatgrandchild2": "[8]"
                                }
                            }
                }
            }
}

z = (1, 2)

#print(type(z))

def get_keys(d, curr_key=[]):
    for k, v in d.items():
        if isinstance(v, dict):
            yield from get_keys(v, curr_key + [k])
        elif isinstance(v, list):
            print("bingo")
            for i in v:
                yield from get_keys(i, curr_key + [k])
        else:
            print("bingo2")
            yield '.'.join(curr_key + [k])

#print([*get_keys(d)])


def get_date(d, curr_key=[]):
    for k, v in d.items():
        if isinstance(v, dict):
            yield from get_date(v, curr_key + [k])
        elif isinstance(v, list):
            for i in v:
                yield from get_date(i, curr_key + [k])
        elif isinstance (v, str):
        	#print("bingo", v)
        #	v = [v]
        	#print(type(curr_key))        	
        	yield '.'.join(curr_key + [k] + [v])
        else:
          #  v = list(v)
            #print(v)
            yield '.'.join(curr_key + [k])



deals = [*get_date(d)]

for count, deal in enumerate(deals):
	print(count, deal)
