def average():
    count = 0
    summ = 0
    average = 0

    while True:
        try:
            x = yield average
        except StopIteration:
            print('Done')
        else:
            count += 1
            summ += x
            average = round(summ / count, 2)


a = average()
print(a.send(None))
print(a.send(5))
print(a.send(7))
print(a.send(13))


 
# Use of yield
def printresult(String) : 
    for i in String:
        if i == "G": 
            yield i
  
# initializing string 
String = "GeeksforGeeks" 
ans = 0
print ("The number of 'e' in word is : ", end = "" ) 
String = String.strip() 
  


for j in printresult(String): 
    ans = ans + 1
   # print(j)
  
print (ans)