from config import agenda
import time

# add player
#today = str(datetime.now())
today = time.strftime("%Y-%m-%d-%M-%s")


start_time = time.time()

def main():
	agenda.deleting_date()
	deals = agenda.getting_deals()
	agenda.writing_deals(agenda.find_daily(), agenda.check_deadline(deals))
	while True:
		agenda.data_to_email("agenda_1.txt")
		try:
			command =input("enter command: standing of date - 0, buying - 1, sellings - 2, sending - 3, vinelie_money - 4, branchs_delivery - 5, break - X: ")
			if command == "0":
				pass
			elif command == "1":
				pass
			elif command == "2":
				pass
			elif command == "3":
				pass
			elif command == "4":
				pass
			elif command == "5":
				pass
			elif command == "X":
				break
			#command = None
		except ex as error:
			print("incorrect command, try again")

if __name__ == "__main__":
    main()
    print('finish_time:', time.time() - start_time)