import time
from datetime import datetime
import math
import json
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# timeit
# TO DO:check deleting deals in fact.

today = time.strftime("%Y-%m-%d %H:%M")
now = datetime.now()
current_week = time.strftime("%V")

class Chrono:
	def __init__(self):
		self.date = date
		
	def standup_today_date(today, date):
		print("today", today)
		

class Agenda:
	def __init__(self, date):
		self.date = today
		
	def get_keys(self):
		pass		
	def taking_categories(self, categories: tuple):
		d = {}
		for x in range(1, 10):
			d["string{0}".format(x)] = "Hello"
			
		today_category_deals = []
		category_deals = []
		for category in categories:
			pass
		
		today_category_deals = []
		for category in categories:
			category = agenda.making_deals(deals, category)
			today_category_deals.append(category)
		
		
		return today_category_deals
		
	
	def making_deals(self, deals: list, category: tuple):
		
		categories_deals = []
		trigger = False
		
		for deal in deals:
						if category in deal[-1]:
							trigger = True
						if trigger:
			#				deal = str(deal)
						#	print(deal)
				#			json_deal = json.loads(deal)
#							print(json_deal)
							categories_deals.append(deal)
						if len(deal[-1]) < 2:
							trigger = False
							
		return categories_deals[1:]
		
		

	def check_deadline(self, deals):
		act_deals = []
		dead_line_deals = []
		range = 10000
		f = 444
		for count, deal in enumerate(deals):
			if "&&&"  in deal[-1] or "%%%" in deal[-1]:
				range = count
			if "2022" in (deal[-1]) and count > range and count < 444:
				date = deal[-1].strip()
				try:
									date = datetime.strptime(date, "%Y-%m-%d %H:%M")
									if date <= now:
										dead_line_deals.append(deal)
																				
				except ValueError:
									date = datetime.strptime(date, "%Y-%m-%d")
									if date <= now:
										dead_line_deals.append(deal)
				
				#except:
#					print(count)	
		return dead_line_deals		
		
						
	def find_daily(self):
		daily = []
		with open('agenda_1.txt', 'r', encoding='utf-8') as agenda:
			for i in agenda:
				if "daily" in i:
					i.replace('\n', '')
					daily.append(i)
					daily_deals = "".join(daily)
		return daily_deals
	
	
	def getting_deals(self):
				deals =  []
		#		data = json.loads('{"lat":444, "lon":555}')
#				print(data)
		#		print(data['lat'])
				with open('agenda_1.txt', 'r', encoding='utf-8') as agenda:
					for count, i in enumerate(agenda):
							try:
			#					json_deal = json.loads(i)
					#			print("json deal", count, json_deal)
		#						for key, value in json_deal.items():
					#				print(value)
								deal = list(i.split("."))
								deals.append(deal)
							except:
								pass
								#print("error: ", i)				
				return deals	
		

	def deleting_date(self):
		with open('agenda_1.txt', 'r', encoding='utf-8') as agenda:
			data = agenda.read().splitlines(True)
			print(f"{f'file was opening'}")

		with open('agenda_1.txt', 'w', encoding='utf-8') as f:
			f.writelines(data[1:])
					
	
	def writing_deals(self, daily, dead_line_deals):
			with open('agenda_1.txt', 'r', encoding='utf-8') as agenda:
				data_01 = agenda.readlines()
			with open('agenda_1.txt', 'w', encoding='utf-8') as f:
				f.write(f'{today:>15}\n')
				f.write(daily)
				f.write(f"                        {'DEADLINE_DEALS'}\n")
				delete_deals =[]
				for deal in dead_line_deals:
								dead_line_deal = ".".join(map(str, deal)).replace("[","").replace("]", "").replace("'","").replace(",",".")
								f.write(f"{dead_line_deal}\n")
				for line in data_01:
								triger = True
								for deal in dead_line_deals:
										dead_line_deal = ".".join(map(str, deal)).replace("[","").replace("]", "").replace("'","")
										if dead_line_deal in line:
											triger = False
								if triger:
									f.write(line)


	def data_to_email(self, attach_file_name):
		try:
			print(f'{"sending of data"}')
			mail_content = '''backup of cars app ''' + today
			sender_address = "anatole.yakovlev@gmail.com"
			sender_pass = "tbunoakrikzyszdv"
			receiver_address = "antiohy@mail.ru"
			message = MIMEMultipart()
			message['From'] = sender_address
			message['To'] = receiver_address
			message['Subject'] = 'A backup mail sent by agandies app. It has an attachment. ' + today
			message.attach(MIMEText(mail_content, 'plain'))
			#attach_file_name = name_of_backup
			attach_file = open(attach_file_name, 'rb')
			payload = MIMEBase('application', 'octate-stream')
			payload.set_payload((attach_file).read())
			encoders.encode_base64(payload)
			payload.add_header('Content-Decomposition', 'attachment', filename=attach_file_name)
			message.attach(payload)
			session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
			session.starttls() #enable security
			session.login(sender_address, sender_pass) #login with mail_id and password
			text = message.as_string()
			session.sendmail(sender_address, receiver_address, text)
			session.quit()
			print("backup was sending")
		except:
			print(f"{'check internet connection'}")

agenda = Agenda(today)


agenda.data_to_email('config.py')


deals = agenda.getting_deals()

categories = ("CALLS#", "TRAVEL#", "FLAT#", "PHONE#", "MIND#", "FAMELY#", "ARROW#")


date = agenda.taking_categories(categories)
#print("bingo", date)

Chrono.standup_today_date(today, date)
